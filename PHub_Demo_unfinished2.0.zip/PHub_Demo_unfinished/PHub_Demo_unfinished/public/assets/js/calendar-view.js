/*
 * PHub cleaning schedule calendar. Needs FullCalendar 6 (global build) loaded first.
 *
 *   PHubCalendar.mount('#phub-calendar', {
 *     getCleaningTasks() {}, onCleaningUpdate(task) {}, onCleaningDone(taskId) {}
 *   });
 */
(function () {
  function mount(target, opts) {
    opts = opts || {};
    var root = typeof target === 'string' ? document.querySelector(target) : target;
    if (!root) throw new Error('PHubCalendar: mount point not found');
    if (!window.FullCalendar) throw new Error('PHubCalendar: load FullCalendar before calendar-view.js');

    var hook = function (name, arg) {
      if (typeof opts[name] === 'function') return opts[name](arg);
    };

    root.innerHTML =
      '<div class="phub-cal">' +
        '<div class="phub-cal__bar"><span>Cleaning schedules for rooms and beds. Click an active task to extend it, or reschedule it after its planned end.</span>' +
        '<span class="phub-cal__live" data-state="ok">Ready</span></div>' +
        '<div class="phub-cal__legend"><span class="is-cleaning">Cleaning task · 48-hour minimum</span></div>' +
        '<div class="phub-cal__grid"></div>' +
        '<dialog class="phub-cal__dialog phub-cal__schedule-dialog"><form novalidate>' +
          '<h3>Schedule cleaning</h3>' +
          '<label class="phub-cal__field">Room and bed<select name="roomBed" required></select></label>' +
          '<label class="phub-cal__field">Cleaning starts<input name="scheduleStart" type="datetime-local" required step="60"></label>' +
          '<label class="phub-cal__field">Planned end<input name="scheduleEnd" type="datetime-local" required step="60"></label>' +
          '<p class="phub-cal__status">The bed remains available until cleaning starts, then stays unavailable until marked complete. Minimum duration: 48 hours.</p>' +
          '<p class="phub-cal__error" role="alert"></p>' +
          '<div class="phub-cal__actions">' +
            '<button type="button" data-act="schedule-close">Cancel</button>' +
            '<button type="submit" class="is-primary">Schedule cleaning</button>' +
          '</div>' +
        '</form></dialog>' +
        '<dialog class="phub-cal__dialog phub-cal__cleaning-dialog"><form novalidate>' +
          '<h3>Cleaning task</h3>' +
          '<p class="phub-cal__cleaning-detail"></p>' +
          '<label class="phub-cal__field">Cleaning starts<input name="cleaningStart" type="datetime-local" required step="60"></label>' +
          '<label class="phub-cal__field">Planned end<input name="cleaningEnd" type="datetime-local" required step="60"></label>' +
          '<p class="phub-cal__status"></p>' +
          '<p class="phub-cal__error" role="alert"></p>' +
          '<div class="phub-cal__actions">' +
            '<button type="button" data-act="cleaning-close">Close</button>' +
            '<button type="button" class="is-done-btn" data-act="cleaning-done">Mark complete</button>' +
            '<button type="submit" class="is-primary">Extend schedule</button>' +
          '</div>' +
        '</form></dialog>' +
      '</div>';

    var liveEl = root.querySelector('.phub-cal__live');
    var scheduleDialog = root.querySelector('.phub-cal__schedule-dialog');
    var scheduleForm = scheduleDialog.querySelector('form');
    var scheduleErrorEl = scheduleDialog.querySelector('.phub-cal__error');
    var scheduleSaveBtn = scheduleForm.querySelector('[type="submit"]');
    var cleaningDialog = root.querySelector('.phub-cal__cleaning-dialog');
    var cleaningForm = cleaningDialog.querySelector('form');
    var cleaningErrorEl = cleaningDialog.querySelector('.phub-cal__error');
    var cleaningDetailEl = cleaningDialog.querySelector('.phub-cal__cleaning-detail');
    var cleaningDoneBtn = cleaningForm.querySelector('[data-act="cleaning-done"]');
    var cleaningSaveBtn = cleaningForm.querySelector('[type="submit"]');
    var activeCleaningTask = null;
    var cleaningMinimumEnd = null;
    var isCleaningOverdue = false;
    var scheduleMinimumEnd = null;

    function pad(n) { return String(n).padStart(2, '0'); }
    function toLocalInput(date) {
      return date.getFullYear() + '-' + pad(date.getMonth() + 1) + '-' + pad(date.getDate()) +
        'T' + pad(date.getHours()) + ':' + pad(date.getMinutes());
    }
    function readLocalDate(input) {
      var parts = input.value.split(/[-T:]/).map(Number);
      if (parts.length !== 5 || parts.some(function (part) { return !Number.isFinite(part); })) return new Date(NaN);
      return new Date(parts[0], parts[1] - 1, parts[2], parts[3], parts[4]);
    }
    function openScheduleDialog(start) {
      if (typeof opts.getAvailableBeds !== 'function') {
        throw new Error('Available beds cannot be loaded.');
      }
      var beds = opts.getAvailableBeds();
      if (!beds.length) {
        window.alert('There are no available beds to schedule for cleaning.');
        return;
      }
      var startDate = new Date(start);
      startDate.setSeconds(0, 0);
      var now = new Date();
      now.setSeconds(0, 0);
      if (startDate < now) startDate = now;
      var endDate = new Date(startDate.getTime() + 48 * 60 * 60 * 1000);
      scheduleForm.roomBed.replaceChildren();
      beds.forEach(function (bed) {
        var value = bed.room + '|' + bed.bedNumber;
        var option = document.createElement('option');
        option.value = value;
        option.textContent = bed.room + ' · Bed ' + bed.bedNumber;
        scheduleForm.roomBed.appendChild(option);
      });
      scheduleErrorEl.textContent = '';
      scheduleForm.scheduleStart.value = toLocalInput(startDate);
      scheduleForm.scheduleEnd.value = toLocalInput(endDate);
      scheduleMinimumEnd = endDate;
      scheduleForm.scheduleEnd.min = toLocalInput(scheduleMinimumEnd);
      scheduleDialog.showModal();
    }
    function closeScheduleDialog() {
      scheduleDialog.close();
      scheduleSaveBtn.disabled = false;
    }
    function cleaningTaskDates(task) {
      var start = task.start ? new Date(task.start) :
        new Date(String(task.time || '').replace(/\s*\(Google Calendar API\)$/, ''));
      if (isNaN(start)) throw new Error('This cleaning task has an invalid start date.');
      var minimumEnd = new Date(start.getTime() + 48 * 60 * 60 * 1000);
      var end = task.end ? new Date(task.end) : minimumEnd;
      if (isNaN(end) || end < minimumEnd) end = minimumEnd;
      return { start: start, end: end, minimumEnd: minimumEnd };
    }
    function getTasks() {
      return typeof opts.getCleaningTasks === 'function' ? opts.getCleaningTasks() : [];
    }
    function openCleaningTask(taskId) {
      var task = getTasks().find(function (item) { return String(item.id) === String(taskId); });
      if (!task) throw new Error('This cleaning task could not be found.');
      var dates = cleaningTaskDates(task);
      activeCleaningTask = task;
      isCleaningOverdue = dates.end < new Date();
      var start = dates.start;
      var end = dates.end;
      var now = new Date();
      now.setSeconds(0, 0);
      if (now.getTime() < Date.now()) now.setMinutes(now.getMinutes() + 1);
      if (isCleaningOverdue) {
        start = now;
        end = new Date(start.getTime() + 48 * 60 * 60 * 1000);
        cleaningForm.cleaningStart.readOnly = false;
        cleaningForm.cleaningStart.min = toLocalInput(start);
        cleaningForm.querySelector('h3').textContent = 'Reschedule cleaning';
        cleaningSaveBtn.textContent = 'Reschedule';
        cleaningForm.querySelector('.phub-cal__status').textContent =
          'The previous schedule has ended. Choose a new start and end; the new period must be at least 48 hours. The bed stays unavailable until marked complete.';
      } else {
        cleaningForm.cleaningStart.readOnly = true;
        cleaningForm.cleaningStart.removeAttribute('min');
        cleaningForm.querySelector('h3').textContent = 'Cleaning task';
        cleaningSaveBtn.textContent = 'Extend schedule';
        cleaningForm.querySelector('.phub-cal__status').textContent =
          'Cleaning is scheduled for at least 48 hours. You may mark it complete earlier if the bed is ready.';
      }
      var earliestEnd = isCleaningOverdue
        ? start.getTime() + 48 * 60 * 60 * 1000
        : Math.max(dates.minimumEnd.getTime(), dates.end.getTime() + 60 * 1000);
      cleaningMinimumEnd = new Date(Math.ceil(earliestEnd / 60000) * 60000);
      cleaningErrorEl.textContent = '';
      cleaningDetailEl.textContent = task.room + ' · Bed ' + task.bedNumber;
      cleaningForm.cleaningStart.value = toLocalInput(start);
      cleaningForm.cleaningEnd.value = toLocalInput(end);
      cleaningForm.cleaningEnd.min = toLocalInput(cleaningMinimumEnd);
      cleaningDialog.showModal();
    }
    function closeCleaningDialog() {
      cleaningDialog.close();
      activeCleaningTask = null;
      isCleaningOverdue = false;
      cleaningDoneBtn.disabled = false;
      cleaningSaveBtn.disabled = false;
    }
    function cleaningEvents(info) {
      var from = new Date(info.start);
      var to = new Date(info.end);
      return getTasks().map(function (task) {
        var dates;
        try {
          dates = cleaningTaskDates(task);
        } catch (err) {
          console.error(err);
          return null;
        }
        if (dates.end <= from || dates.start >= to) return null;
        return {
          id: 'cleaning-' + task.id,
          title: task.room + ' · Bed ' + task.bedNumber + ' cleaning',
          start: dates.start,
          end: dates.end,
          backgroundColor: '#b45309',
          borderColor: '#f59e0b',
          textColor: '#fff',
          editable: false,
          classNames: ['is-cleaning-task'],
          extendedProps: { type: 'cleaning', cleaningId: task.id },
        };
      }).filter(Boolean);
    }

    var calendar = new FullCalendar.Calendar(root.querySelector('.phub-cal__grid'), {
      initialView: 'dayGridMonth',
      headerToolbar: { left: 'prev,next today', center: 'title', right: 'dayGridMonth,timeGridWeek,listWeek' },
      height: 'auto',
      allDaySlot: false,
      nowIndicator: true,
      selectable: true,
      editable: false,
      dayMaxEvents: 4,
      events: function (info, success) {
        success(cleaningEvents(info));
      },
      selectAllow: function (selection) {
        var today = new Date();
        today.setHours(0, 0, 0, 0);
        return selection.start >= today;
      },
      select: function (info) {
        var start = new Date(info.start);
        if (info.allDay) start.setHours(8, 0, 0, 0);
        openScheduleDialog(start);
      },
      eventClick: function (info) {
        if (info.event.extendedProps.type === 'cleaning') {
          openCleaningTask(info.event.extendedProps.cleaningId);
        }
      },
    });
    calendar.render();
    cleaningForm.cleaningStart.addEventListener('change', function () {
      if (!isCleaningOverdue) return;
      var start = readLocalDate(cleaningForm.cleaningStart);
      if (isNaN(start)) return;
      cleaningMinimumEnd = new Date(start.getTime() + 48 * 60 * 60 * 1000);
      cleaningForm.cleaningEnd.min = toLocalInput(cleaningMinimumEnd);
      if (readLocalDate(cleaningForm.cleaningEnd) < cleaningMinimumEnd) {
        cleaningForm.cleaningEnd.value = toLocalInput(cleaningMinimumEnd);
      }
    });

    scheduleForm.scheduleStart.addEventListener('change', function () {
      var start = readLocalDate(scheduleForm.scheduleStart);
      if (isNaN(start)) return;
      scheduleMinimumEnd = new Date(start.getTime() + 48 * 60 * 60 * 1000);
      scheduleForm.scheduleEnd.min = toLocalInput(scheduleMinimumEnd);
      if (readLocalDate(scheduleForm.scheduleEnd) < scheduleMinimumEnd) {
        scheduleForm.scheduleEnd.value = toLocalInput(scheduleMinimumEnd);
      }
    });

    scheduleForm.addEventListener('submit', function (event) {
      event.preventDefault();
      if (typeof opts.onCleaningCreate !== 'function') {
        scheduleErrorEl.textContent = 'Scheduling cleaning tasks is unavailable.';
        return;
      }
      var bedChoice = scheduleForm.roomBed.value.split('|');
      var start = readLocalDate(scheduleForm.scheduleStart);
      var end = readLocalDate(scheduleForm.scheduleEnd);
      if (bedChoice.length !== 2 || !bedChoice[0] || !Number.isInteger(Number(bedChoice[1]))) {
        scheduleErrorEl.textContent = 'Choose an available room and bed.';
        return;
      }
      if (isNaN(start) || isNaN(end) || end < new Date(start.getTime() + 48 * 60 * 60 * 1000)) {
        scheduleErrorEl.textContent = 'The planned end must be at least 48 hours after the cleaning start.';
        return;
      }
      scheduleSaveBtn.disabled = true;
      Promise.resolve(hook('onCleaningCreate', {
        room: bedChoice[0],
        bedNumber: Number(bedChoice[1]),
        start: start.toISOString(),
        end: end.toISOString()
      }))
        .then(function (saved) {
          if (saved === false) throw new Error('This cleaning task could not be scheduled.');
          closeScheduleDialog();
          calendar.refetchEvents();
        })
        .catch(function (err) {
          scheduleErrorEl.textContent = err.message || 'This cleaning task could not be scheduled.';
          scheduleSaveBtn.disabled = false;
        });
    });
    scheduleForm.querySelector('[data-act="schedule-close"]').addEventListener('click', closeScheduleDialog);

    cleaningForm.addEventListener('submit', function (event) {
      event.preventDefault();
      if (!activeCleaningTask) return;
      if (typeof opts.onCleaningUpdate !== 'function') {
        cleaningErrorEl.textContent = 'Updating cleaning schedules is unavailable.';
        return;
      }
      var start = readLocalDate(cleaningForm.cleaningStart);
      var end = new Date(cleaningForm.cleaningEnd.value);
      if (isNaN(start) || isNaN(end) || end < new Date(start.getTime() + 48 * 60 * 60 * 1000)) {
        cleaningErrorEl.textContent = 'Choose a valid start and an end time at least 48 hours later.';
        return;
      }
      if (isCleaningOverdue) {
        var earliestStart = new Date();
        earliestStart.setSeconds(0, 0);
        if (earliestStart.getTime() < Date.now()) earliestStart.setMinutes(earliestStart.getMinutes() + 1);
        if (start < earliestStart) {
          cleaningErrorEl.textContent = 'The new cleaning start cannot be in the past.';
          return;
        }
      } else if (cleaningForm.cleaningStart.value !== toLocalInput(new Date(activeCleaningTask.start)) ||
          end < cleaningMinimumEnd) {
        cleaningErrorEl.textContent = 'Choose an end time that extends the current plan and keeps at least 48 hours of cleaning.';
        return;
      }
      cleaningSaveBtn.disabled = true;
      Promise.resolve(hook('onCleaningUpdate', {
        id: activeCleaningTask.id,
        start: start.toISOString(),
        end: end.toISOString(),
        reschedule: isCleaningOverdue
      }))
        .then(function (saved) {
          if (saved === false) throw new Error('The cleaning schedule could not be updated.');
          closeCleaningDialog();
          calendar.refetchEvents();
        })
        .catch(function (err) {
          cleaningErrorEl.textContent = err.message || 'The cleaning schedule could not be updated.';
          cleaningSaveBtn.disabled = false;
        });
    });

    cleaningDoneBtn.addEventListener('click', function () {
      if (!activeCleaningTask) return;
      if (typeof opts.onCleaningDone !== 'function') {
        cleaningErrorEl.textContent = 'Completing cleaning tasks is unavailable.';
        return;
      }
      cleaningDoneBtn.disabled = true;
      Promise.resolve(hook('onCleaningDone', activeCleaningTask.id))
        .then(function (completed) {
          if (completed === false) throw new Error('This cleaning task could not be completed.');
          closeCleaningDialog();
          calendar.refetchEvents();
        })
        .catch(function (err) {
          cleaningErrorEl.textContent = err.message || 'This cleaning task could not be completed.';
          cleaningDoneBtn.disabled = false;
        });
    });

    cleaningForm.querySelector('[data-act="cleaning-close"]').addEventListener('click', closeCleaningDialog);

    return {
      refresh: function () { calendar.refetchEvents(); },
      resize: function () { calendar.updateSize(); },
      openCleaningTask: openCleaningTask,
      calendar: calendar
    };
  }

  window.PHubCalendar = { mount: mount };
})();
