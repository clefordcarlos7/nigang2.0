let rooms = [];
let patients = [];
let doctors = [];
let nurses = [];
let cleaningSchedules = [];
let legacyCleaningSchedules = [];
let legacyCleaningImportAttempted = false;

const appDataStorageKey = 'phub.data';
const hiddenAdminTriggerUser = 'admin6767';
const hiddenAdminClickThreshold = 10;
const expandedWardRooms = new Set();
let registrationUnlocked = false;
let adminShortcutClickCount = 0;
let accountMessageTimer = null;
let notificationTimer = null;
let currentUser = null;
let accountCache = [];
let promotionRequestsCache = [];
let ownPromotionRequest = null;
let invitationToken = new URLSearchParams(window.location.search).get('invite') || '';
let pendingAdmissionRoomId = null;
let prioritizedPatientRoomId = null;

function getRoomPatients(room) {
    return patients.filter(patient => patient.room === room.number);
}

function renderStaffAssignmentPanel() {
    const list = document.getElementById('staff-assignment-list');
    if (!list) return;

    const assignments = rooms.flatMap(room => room.staff
        .filter(member => member.role === 'Nurse')
        .map(member => ({ ...member, roomNumber: room.number })));
    list.innerHTML = assignments.length
        ? assignments.map(member => `
            <li>
                <span>${escapeHtml(member.name)} (${escapeHtml(member.id)}) - Room ${escapeHtml(member.roomNumber)}</span>
                <button type="button" class="btn danger-btn unassign-room-staff-btn"
                    data-assignment-id="${escapeHtml(member.assignmentId)}"
                    data-staff-name="${escapeHtml(member.name)}"
                    data-room-number="${escapeHtml(member.roomNumber)}">Unassign</button>
            </li>
        `).join('')
        : '<li>No nurses are currently assigned to rooms.</li>';
}

function showNotification(message) {
    const toast = document.getElementById('notification-toast');
    if (!toast) return;
    window.clearTimeout(notificationTimer);
    toast.textContent = message;
    toast.classList.remove('hidden');
    notificationTimer = window.setTimeout(() => toast.classList.add('hidden'), 4000);
}

const staffAssignmentList = document.getElementById('staff-assignment-list');
if (staffAssignmentList) {
    staffAssignmentList.addEventListener('click', async event => {
        const button = event.target.closest('.unassign-room-staff-btn');
        if (!button) return;
        if (!await showConfirmation(
            `Unassign ${button.dataset.staffName} from Room ${button.dataset.roomNumber}?`
        )) return;

        button.disabled = true;
        try {
            await apiRequest(`/api/clinical/nurse-assignments/${encodeURIComponent(button.dataset.assignmentId)}`, {
                method: 'DELETE'
            });
            await refreshClinicalData();
            showNotification('Nurse unassigned from the room.');
        } catch (err) {
            button.disabled = false;
            document.getElementById('storage-error').textContent =
                `Could not unassign nurse: ${err.message}`;
        }
    });
}

function showConfirmation(message) {
    const modal = document.getElementById('confirm-modal');
    const messageElement = document.getElementById('confirm-modal-message');
    const cancelButton = document.getElementById('confirm-modal-cancel');
    const submitButton = document.getElementById('confirm-modal-submit');
    if (!modal || !messageElement || !cancelButton || !submitButton) {
        return Promise.resolve(false);
    }
    messageElement.textContent = message;
    modal.classList.remove('hidden');
    return new Promise(resolve => {
        const finish = result => {
            modal.classList.add('hidden');
            cancelButton.removeEventListener('click', onCancel);
            submitButton.removeEventListener('click', onSubmit);
            resolve(result);
        };
        const onCancel = () => finish(false);
        const onSubmit = () => finish(true);
        cancelButton.addEventListener('click', onCancel);
        submitButton.addEventListener('click', onSubmit);
    });
}

function getAvailableBedNumber(room) {
    for (const bed of room.beds) {
        if (getBedStatus(room, bed.bedNumber) === 'Available') return bed.bedNumber;
    }
    return null;
}

function getRoomCapacity(room) {
    return room.beds.length;
}

function getRoomStatus(room) {
    if (!room.beds.length) return 'No Beds';
    const statuses = room.beds.map(bed => getBedStatus(room, bed.bedNumber));
    if (statuses.every(status => status === 'Maintenance')) return 'Maintenance';
    if (statuses.every(status => status === 'Cleaning')) return 'Cleaning';
    if (statuses.every(status => status === 'Occupied')) return 'Occupied';
    return 'Available';
}

function canChangeRoomStatus(room) {
    return getRoomStatus(room) === 'Available' &&
        getRoomPatients(room).length === 0 &&
        !cleaningSchedules.some(schedule => room.beds.some(bed => bed.id === schedule.bedId));
}

function getBedStatus(room, bedNumber) {
    const bed = room.beds.find(item => item.bedNumber === bedNumber);
    if (!bed) return 'Unavailable';
    if (patients.some(patient => patient.bedId === bed.id)) return 'Occupied';
    if (cleaningSchedules.some(schedule =>
        schedule.bedId === bed.id &&
        new Date(schedule.start) <= new Date()
    )) {
        return 'Cleaning';
    }
    return bed.status;
}

function canAdmitToRoom(room) {
    return getAvailableBedNumber(room) !== null;
}

function showDashboardTab(target) {
    const tabButton = document.querySelector(`.tab-btn[data-target="${target}"]`);
    if (tabButton) tabButton.click();
}

function prepareAdmissionForRoom(room) {
    pendingAdmissionRoomId = room.id;
    showDashboardTab('patients-tab');
    document.getElementById('patient-room-type').value = room.type;
    populateSelectDropdowns();
    const availableBed = getAvailableBedNumber(room);
    if (availableBed !== null) {
        document.getElementById('available-rooms-select').value =
            room.beds.find(bed => bed.bedNumber === availableBed)?.id || '';
    }
}

function prepareStaffAssignmentForRoom(room) {
    showDashboardTab('staff-tab');
    staffRoleSelect.value = 'Nurse';
    populateSelectDropdowns();
    document.getElementById('staff-room-select').value = room.id;
}

function preparePatientManagementForRoom(room) {
    prioritizedPatientRoomId = room.number;
    showDashboardTab('patients-tab');
    renderPatients();
    const firstPatientRow = document.querySelector('#patients-table tbody tr');
    if (firstPatientRow) firstPatientRow.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function loadAppData() {
    const stored = localStorage.getItem(appDataStorageKey);
    if (!stored) {
        return;
    }

    const data = JSON.parse(stored);
    if (!data || !Array.isArray(data.cleaningSchedules)) {
        throw new Error('Saved PHub cleaning data is invalid and must be repaired or cleared.');
    }

    legacyCleaningSchedules = data.cleaningSchedules;
}

function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, character => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    })[character]);
}

// DOM Elements
const loginContainer = document.getElementById('login-container');
const dashboardContainer = document.getElementById('dashboard-container');
const loginForm = document.getElementById('login-form');
const loginError = document.getElementById('login-error');
const registerForm = document.getElementById('register-form');
const registerError = document.getElementById('register-error');
const registrationAccessForm = document.getElementById('registration-access-form');
const registrationAccessError = document.getElementById('registration-access-error');
const showLoginBtn = document.getElementById('show-login-btn');
const showRegisterBtn = document.getElementById('show-register-btn');
const logoutBtn = document.getElementById('logout-btn');
const userRoleBadge = document.getElementById('user-role-badge');
const staffRoleSelect = document.getElementById('staff-role-select');

try {
    loadAppData();
} catch (err) {
    loginError.textContent = err instanceof Error ? err.message : 'Could not load saved PHub data.';
    console.error(err);
}

function normalizeUsername(value) {
    return typeof value === 'string' ? value.trim().toLowerCase() : '';
}

function getPromotionRequests() {
    return promotionRequestsCache;
}

async function apiRequest(url, options = {}) {
    const response = await fetch(url, {
        method: options.method || 'GET',
        credentials: 'same-origin',
        headers: options.body ? { 'Content-Type': 'application/json' } : {},
        body: options.body ? JSON.stringify(options.body) : undefined
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
        throw new Error(payload.error || `Request failed (${response.status}).`);
    }
    return payload;
}

async function refreshClinicalData() {
    const data = await apiRequest('/api/clinical');
    if (legacyCleaningSchedules.length && !legacyCleaningImportAttempted) {
        legacyCleaningImportAttempted = true;
        try {
            const result = await apiRequest('/api/clinical/cleaning-schedules/import', {
                method: 'POST',
                body: {
                    schedules: legacyCleaningSchedules.map(item => ({
                        bedId: item.bedId,
                        start: item.start,
                        end: item.end,
                        status: item.status
                    }))
                }
            });
            if (result.imported) {
                localStorage.removeItem(appDataStorageKey);
                legacyCleaningSchedules = [];
            } else {
                document.getElementById('storage-error').textContent =
                    'Saved browser cleaning schedules were not imported because MySQL already has cleaning schedules. The browser copy is preserved.';
            }
        } catch (err) {
            document.getElementById('storage-error').textContent =
                `Saved browser cleaning schedules could not be imported; the browser copy is preserved: ${err.message}`;
        }
    }
    const cleaning = await apiRequest('/api/clinical/cleaning-schedules');
    rooms = data.rooms;
    patients = data.patients;
    doctors = data.doctors;
    nurses = data.nurses;
    cleaningSchedules = cleaning.schedules;
    renderAll();
    const floorPlanFrame = document.getElementById('floor-plan-frame');
    if (floorPlanFrame?.contentWindow) {
        floorPlanFrame.contentWindow.postMessage({ type: 'phub-clinical-data-updated' }, window.location.origin);
    }
}

window.addEventListener('message', event => {
    if (event.origin !== window.location.origin || !event.data ||
        event.data.type !== 'phub-floor-room-action') return;

    const room = rooms.find(item => item.id === String(event.data.roomId));
    if (!room) return;

    if (event.data.action === 'manage-staff') {
        prepareStaffAssignmentForRoom(room);
    } else if (event.data.action === 'add-patient' && canAdmitToRoom(room)) {
        prepareAdmissionForRoom(room);
    } else if (event.data.action === 'manage-patient' && getRoomPatients(room).length) {
        preparePatientManagementForRoom(room);
    }
});

function getAccounts() {
    return accountCache;
}

function getCurrentSessionUser() {
    return currentUser;
}

function extractInvitationToken(value) {
    const input = value.trim();
    if (!input) return '';
    try {
        const parsed = new URL(input, window.location.origin);
        return parsed.searchParams.get('invite') || input;
    } catch (err) {
        return input;
    }
}

async function refreshAccountData() {
    if (!currentUser) return;
    const mine = await apiRequest('/api/promotion-requests/mine');
    ownPromotionRequest = mine.request;
    promotionRequestsCache = [];
    accountCache = [];

    if (['System Admin', 'Head Nurse'].includes(currentUser.role)) {
        const pending = await apiRequest('/api/promotion-requests');
        promotionRequestsCache = pending.requests;
    }
    if (currentUser.role === 'System Admin') {
        const users = await apiRequest('/api/users');
        accountCache = users.users;
    }
    renderAll();
}

function renderPromotionStatus(user) {
    const form = document.getElementById('promotion-request-form');
    const statusEl = document.getElementById('promotion-status');
    const promotionCard = document.getElementById('promotion-card');
    if (!form || !statusEl || !promotionCard) return;

    const latestRequest = ownPromotionRequest;
    promotionCard.classList.toggle('hidden', user.role !== 'Nurse' && !latestRequest);
    form.classList.toggle('hidden', user.role !== 'Nurse' ||
        !!(latestRequest && ['Pending', 'Approved'].includes(latestRequest.status)));
    if (!latestRequest) {
        statusEl.textContent = 'No promotion request yet';
        statusEl.className = 'status-badge status-available';
        return;
    }

    if (latestRequest.status === 'Approved') {
        statusEl.textContent = `Promotion approved on ${new Date(latestRequest.decisionDate || latestRequest.submittedAt).toLocaleDateString()}`;
        statusEl.className = 'status-badge status-occupied';
    } else if (latestRequest.status === 'Rejected') {
        statusEl.textContent = `Promotion rejected on ${new Date(latestRequest.decisionDate || latestRequest.submittedAt).toLocaleDateString()}`;
        statusEl.className = 'status-badge status-cleaning';
    } else {
        statusEl.textContent = 'Promotion pending approval';
        statusEl.className = 'status-badge status-available';
        form.classList.add('hidden');
    }
}

function renderHeadNurseRequests() {
    const panel = document.getElementById('head-nurse-requests-panel');
    if (!panel) return;

    const currentUser = getCurrentSessionUser();
    const isHeadNurseWithAccess = currentUser && ['Head Nurse', 'System Admin'].includes(currentUser.role);
    panel.classList.toggle('hidden', !isHeadNurseWithAccess);
    if (!isHeadNurseWithAccess) return;

    const requestsList = document.getElementById('promotion-requests-list');
    if (!requestsList) return;
    const requests = getPromotionRequests().filter(request => request.status === 'Pending');
    if (!requests.length) {
        requestsList.innerHTML = '<p class="security-notice">No pending promotion requests.</p>';
        return;
    }

    requestsList.innerHTML = requests.map(request => `
        <div class="request-card">
            <div>
                <strong>${escapeHtml(request.requesterName || request.requesterUsername)}</strong>
                <p>Requested: ${new Date(request.submittedAt).toLocaleDateString()}</p>
            </div>
            <div class="request-actions">
                <button type="button" class="btn secondary-btn" data-request-action="approve" data-request-id="${request.id}">Approve</button>
                <button type="button" class="btn danger-btn" data-request-action="reject" data-request-id="${request.id}">Reject</button>
            </div>
        </div>
    `).join('');
}

function renderInvitationPanel() {
    const panel = document.getElementById('invitation-management-panel');
    if (!panel) return;
    const permitted = currentUser && ['System Admin', 'Head Nurse'].includes(currentUser.role);
    panel.classList.toggle('hidden', !permitted);
}

function showAccountMessage(text, tone = 'success') {
    const message = document.getElementById('promotion-message');
    if (!message) return;

    if (tone === 'success') showNotification(text);
    window.clearTimeout(accountMessageTimer);
    message.textContent = text;
    message.className = `account-feedback account-feedback-${tone}`;
    accountMessageTimer = window.setTimeout(() => {
        message.textContent = '';
        message.classList.add('hidden');
    }, 5000);
}

function renderAdminManagementPanel() {
    const panel = document.getElementById('admin-management-panel');
    const list = document.getElementById('admin-user-list');
    if (!panel || !list) return;

    const currentUser = getCurrentSessionUser();
    const isAdmin = currentUser && currentUser.role === 'System Admin';
    panel.classList.toggle('hidden', !isAdmin);
    if (!isAdmin) return;

    const accounts = getAccounts();
    list.innerHTML = accounts.filter(account => account.role !== 'System Admin').map(account => `
        <li>
            <span>${escapeHtml(account.fullName || account.username)} (${escapeHtml(account.role)})</span>
            <button type="button" class="btn danger-btn delete-account-btn" data-account-username="${escapeHtml(account.username)}">Delete</button>
        </li>
    `).join('') || '<li>No Nurse or Head Nurse accounts yet.</li>';
}

function renderStaffRemovalPanel() {
    const panel = document.getElementById('staff-removal-card');
    const list = document.getElementById('staff-removal-list');
    if (!panel || !list) return;

    const isAdmin = currentUser && currentUser.role === 'System Admin';
    panel.classList.toggle('hidden', !isAdmin);
    if (!isAdmin) return;

    const staff = [
        ...doctors.map(person => ({ ...person, type: 'doctor', role: 'Doctor' })),
        ...nurses.map(person => ({ ...person, type: 'nurse', role: 'Nurse' }))
    ].sort((left, right) => `${left.lastName} ${left.firstName}`.localeCompare(`${right.lastName} ${right.firstName}`));

    list.innerHTML = staff.map(person => {
        const name = [person.firstName, person.middleName, person.lastName].filter(Boolean).join(' ');
        return `
            <li>
                <span>${escapeHtml(name)} (${escapeHtml(person.role)})</span>
                <button type="button" class="btn danger-btn remove-clinical-staff-btn"
                    data-staff-type="${person.type}" data-staff-id="${escapeHtml(person.id)}"
                    data-staff-name="${escapeHtml(name)}">Remove</button>
            </li>
        `;
    }).join('') || '<li>No doctors or nurses are registered.</li>';
}

function enterDashboard(user) {
    const username = user.user || user.username;
    currentUser = {
        user: username,
        username,
        fullName: user.fullName || username,
        role: user.role,
        createdAt: user.createdAt || null
    };
    loginError.textContent = '';
    registerError.textContent = '';
    loginContainer.classList.add('hidden');
    dashboardContainer.classList.remove('hidden');
    userRoleBadge.textContent = `Role: ${currentUser.role}`;
    document.getElementById('room-create-card').classList.toggle('hidden', currentUser.role !== 'System Admin');
    document.getElementById('bed-create-card').classList.toggle('hidden',
        !['Head Nurse', 'System Admin'].includes(currentUser.role));
    document.getElementById('account-name').textContent = currentUser.fullName;
    document.getElementById('account-username').textContent = currentUser.user;
    document.getElementById('account-role').textContent = currentUser.role;
    document.getElementById('account-created').textContent = currentUser.createdAt
        ? new Date(currentUser.createdAt).toLocaleDateString()
        : 'Existing staff account';
    renderAll();
    refreshClinicalData().catch(err => {
        document.getElementById('storage-error').textContent = `Could not load records from MySQL: ${err.message}`;
    });
    refreshAccountData().catch(err => {
        document.getElementById('storage-error').textContent = `Could not load account management data: ${err.message}`;
    });
}

function setAuthMode(mode) {
    const isLogin = mode === 'login';
    const registrationFormUnlocked = !isLogin && registrationUnlocked;
    const adminPanel = document.getElementById('admin-login-panel');
    if (adminPanel && !isLogin) {
        adminPanel.classList.add('hidden');
    }
    loginForm.classList.toggle('hidden', !isLogin);
    registrationAccessForm.classList.toggle('hidden', isLogin || registrationFormUnlocked);
    registerForm.classList.toggle('hidden', !registrationFormUnlocked);
    showLoginBtn.classList.toggle('active', isLogin);
    showRegisterBtn.classList.toggle('active', !isLogin);
    showLoginBtn.setAttribute('aria-selected', String(isLogin));
    showRegisterBtn.setAttribute('aria-selected', String(!isLogin));
    loginError.textContent = '';
    registerError.textContent = '';
    registrationAccessError.textContent = '';
}

showLoginBtn.addEventListener('click', () => {
    setAuthMode('login');
    adminShortcutClickCount = 0;
    const adminPanel = document.getElementById('admin-login-panel');
    if (adminPanel) adminPanel.classList.add('hidden');
});
showRegisterBtn.addEventListener('click', () => {
    setAuthMode('register');
    const tokenInput = document.getElementById('registration-access-code');
    if (invitationToken && tokenInput) tokenInput.value = invitationToken;
    const adminPanel = document.getElementById('admin-login-panel');
    if (adminPanel) adminPanel.classList.add('hidden');
});

registrationAccessForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    registrationAccessError.textContent = '';
    const token = document.getElementById('registration-access-code').value.trim();
    try {
        invitationToken = extractInvitationToken(token);
        await apiRequest(`/api/invitations/validate?token=${encodeURIComponent(invitationToken)}`);
        registrationUnlocked = true;
        registrationAccessForm.classList.add('hidden');
        registerForm.classList.remove('hidden');
        document.getElementById('register-name').focus();
    } catch (err) {
        registrationAccessError.textContent = err.message;
    }
});

const generateInvitationButton = document.getElementById('generate-invitation-btn');
generateInvitationButton.addEventListener('click', async () => {
    if (!currentUser || !['System Admin', 'Head Nurse'].includes(currentUser.role)) return;
    generateInvitationButton.disabled = true;
    try {
        const result = await apiRequest('/api/invitations', { method: 'POST', body: {} });
        document.getElementById('invitation-link').value = result.url;
        document.getElementById('invitation-expiry').textContent =
            `Expires ${new Date(result.expiresAt).toLocaleString()}. This link can only be used once.`;
        document.getElementById('invitation-result').classList.remove('hidden');
        showAccountMessage('Invitation link generated.');
    } catch (err) {
        showAccountMessage(err.message, 'error');
    } finally {
        generateInvitationButton.disabled = false;
    }
});

document.getElementById('copy-invitation-btn').addEventListener('click', async () => {
    const link = document.getElementById('invitation-link').value;
    try {
        await navigator.clipboard.writeText(link);
        showAccountMessage('Invitation link copied.');
    } catch (err) {
        showAccountMessage('Could not copy automatically. Select and copy the invitation link.', 'error');
    }
});

const adminLoginForm = document.getElementById('admin-login-form');
async function submitLogin(username, password, adminOnly, errorElement) {
    errorElement.textContent = '';
    try {
        const result = await apiRequest('/api/auth/login', {
            method: 'POST',
            body: { username, password, adminOnly }
        });
        enterDashboard(result.user);
    } catch (err) {
        errorElement.textContent = err.message;
    }
}

adminLoginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    await submitLogin(
        document.getElementById('admin-login-username').value.trim(),
        document.getElementById('admin-login-password').value,
        true,
        document.getElementById('admin-login-error')
    );
});

// Tabs Switching
const tabBtns = document.querySelectorAll('.tab-btn');
const tabPanes = document.querySelectorAll('.tab-pane');

tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        tabBtns.forEach(b => b.classList.remove('active'));
        tabPanes.forEach(p => p.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById(btn.dataset.target).classList.add('active');
    });
});

const loginSubmitButton = document.querySelector('#login-form button[type="submit"]');
loginSubmitButton.addEventListener('click', (event) => {
    const usernameInput = document.getElementById('username').value.trim();
    const normalizedUsername = normalizeUsername(usernameInput);
    if (normalizedUsername !== hiddenAdminTriggerUser) {
        return;
    }

    event.preventDefault();
    event.stopPropagation();
    adminShortcutClickCount += 1;
    loginError.textContent = '';
    if (adminShortcutClickCount >= hiddenAdminClickThreshold) {
        adminShortcutClickCount = 0;
        const adminPanel = document.getElementById('admin-login-panel');
        if (adminPanel) {
            adminPanel.classList.remove('hidden');
            document.getElementById('admin-login-username').value = '';
            document.getElementById('admin-login-password').value = '';
            document.getElementById('admin-login-username').focus();
            loginForm.classList.add('hidden');
        }
        loginError.textContent = '';
        return;
    }
});

// Authentication is verified by the Node backend; browser storage is not trusted.
loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const usernameInput = document.getElementById('username').value.trim();
    const normalizedUsername = normalizeUsername(usernameInput);
    const passwordInput = document.getElementById('password').value;

    if (normalizedUsername === hiddenAdminTriggerUser) {
        return;
    }

    await submitLogin(normalizedUsername, passwordInput, false, loginError);
});

registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    registerError.textContent = '';
    if (!registrationUnlocked) {
        registerError.textContent = 'Validate an active staff invitation before registering.';
        return;
    }

    const fullName = document.getElementById('register-name').value.trim();
    const username = normalizeUsername(document.getElementById('register-username').value);
    const password = document.getElementById('register-password').value;
    const confirmPassword = document.getElementById('register-confirm-password').value;

    if (password.length < 8) {
        registerError.textContent = 'Password must be at least 8 characters long.';
        return;
    }
    if (password !== confirmPassword) {
        registerError.textContent = 'Passwords do not match.';
        return;
    }
    try {
        const result = await apiRequest('/api/auth/register', {
            method: 'POST',
            body: { fullName, username, password, invitationToken }
        });
        registerForm.reset();
        invitationToken = '';
        window.history.replaceState({}, document.title, window.location.pathname);
        registrationUnlocked = false;
        enterDashboard(result.user);
    } catch (err) {
        registerError.textContent = err instanceof Error
            ? err.message
            : 'Account creation failed. Please try again.';
        console.error(err);
    }
});

logoutBtn.addEventListener('click', async () => {
    registrationUnlocked = false;
    adminShortcutClickCount = 0;
    try {
        await apiRequest('/api/auth/logout', { method: 'POST', body: {} });
    } catch (err) {
        document.getElementById('storage-error').textContent = `Could not sign out: ${err.message}`;
        console.error(err);
        return;
    }
    currentUser = null;
    accountCache = [];
    promotionRequestsCache = [];
    ownPromotionRequest = null;
    dashboardContainer.classList.add('hidden');
    loginContainer.classList.remove('hidden');
    loginForm.reset();
    adminLoginForm.reset();
    document.getElementById('admin-login-panel').classList.add('hidden');
    document.getElementById('admin-login-error').textContent = '';
    setAuthMode('login');
});

const promotionRequestForm = document.getElementById('promotion-request-form');
if (promotionRequestForm) {
    promotionRequestForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (!currentUser || currentUser.role !== 'Nurse') return;
        try {
            await apiRequest('/api/promotion-requests', { method: 'POST', body: {} });
            showAccountMessage('Promotion request sent. It is now pending approval.');
            await refreshAccountData();
        } catch (err) {
            showAccountMessage(err.message, 'error');
        }
    });
}

const headNurseRequestsPanel = document.getElementById('head-nurse-requests-panel');
if (headNurseRequestsPanel) {
    headNurseRequestsPanel.addEventListener('click', async (e) => {
        const button = e.target.closest('[data-request-action]');
        if (!button) return;

        const currentUser = getCurrentSessionUser();
        if (!currentUser || !['Head Nurse', 'System Admin'].includes(currentUser.role)) return;

        const decision = button.dataset.requestAction === 'approve' ? 'Approved' : 'Rejected';
        try {
            await apiRequest(`/api/promotion-requests/${encodeURIComponent(button.dataset.requestId)}`, {
                method: 'PATCH',
                body: { decision }
            });
            showAccountMessage(`Promotion request ${decision.toLowerCase()}.`);
            await refreshAccountData();
        } catch (err) {
            showAccountMessage(err.message, 'error');
        }
    });
}

const adminUserForm = document.getElementById('admin-user-form');
if (adminUserForm) {
    adminUserForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (!currentUser || currentUser.role !== 'System Admin') return;

        const fullName = document.getElementById('admin-user-fullname').value.trim();
        const username = normalizeUsername(document.getElementById('admin-user-username').value);
        const role = document.getElementById('admin-user-role').value;
        const password = document.getElementById('admin-user-password').value;

        try {
            await apiRequest('/api/users', {
                method: 'POST',
                body: { fullName, username, role, password }
            });
            adminUserForm.reset();
            showAccountMessage('Staff account created.');
            await refreshAccountData();
        } catch (err) {
            showAccountMessage(err.message, 'error');
        }
    });
}

const adminManagementPanel = document.getElementById('admin-management-panel');
if (adminManagementPanel) {
    adminManagementPanel.addEventListener('click', async (event) => {
        const button = event.target.closest('.delete-account-btn');
        if (!button) return;

        if (!currentUser || currentUser.role !== 'System Admin') return;

        const username = button.dataset.accountUsername;
        if (!await showConfirmation(`Delete the staff account "${username}"? This action cannot be undone.`)) return;
        try {
            await apiRequest(`/api/users/${encodeURIComponent(username)}`, { method: 'DELETE' });
            showAccountMessage('Staff account deleted.');
            await refreshAccountData();
        } catch (err) {
            showAccountMessage(err.message, 'error');
        }
    });
}

const staffRemovalCard = document.getElementById('staff-removal-card');
if (staffRemovalCard) {
    staffRemovalCard.addEventListener('click', async (event) => {
        const button = event.target.closest('.remove-clinical-staff-btn');
        if (!button || !currentUser || currentUser.role !== 'System Admin') return;

        const staffName = button.dataset.staffName || button.dataset.staffId;
        const staffType = button.dataset.staffType;
        const label = staffType === 'doctor' ? 'doctor' : 'nurse';
        if (!await showConfirmation(`Remove ${label} "${staffName}"? Their assignments will also be removed.`)) return;

        button.disabled = true;
        try {
            await apiRequest(`/api/clinical/${staffType}s/${encodeURIComponent(button.dataset.staffId)}`, {
                method: 'DELETE'
            });
            await refreshClinicalData();
            showNotification(`${label[0].toUpperCase()}${label.slice(1)} removed successfully.`);
        } catch (err) {
            button.disabled = false;
            document.getElementById('storage-error').textContent = `Could not remove ${label}: ${err.message}`;
        }
    });
}

// Render Functions
function renderAll() {
    renderRooms();
    renderPatients();
    renderCleaning();
    renderStaffAssignmentPanel();
    renderStaffRemovalPanel();
    populateSelectDropdowns();
    renderAccountTab();
    renderInvitationPanel();
}

function renderCleaningState() {
    renderRooms();
    renderCleaning(false);
    populateSelectDropdowns();
}

window.setInterval(() => {
    if (!document.hidden && currentUser) {
        refreshClinicalData().catch(err => {
            document.getElementById('storage-error').textContent = `Could not refresh cleaning schedules: ${err.message}`;
        });
    }
}, 10000);

function renderAccountTab() {
    const currentUser = getCurrentSessionUser();
    const userRole = currentUser && currentUser.role ? currentUser.role : null;
    if (currentUser) {
        userRoleBadge.textContent = `Role: ${userRole}`;
    }
    const accountName = document.getElementById('account-name');
    const accountUsername = document.getElementById('account-username');
    const accountRole = document.getElementById('account-role');
    const accountCreated = document.getElementById('account-created');

    if (currentUser) {
        accountName.textContent = currentUser.fullName || currentUser.user || 'User';
        accountUsername.textContent = currentUser.user || currentUser.username || 'Unknown';
        accountRole.textContent = currentUser.role || 'Nurse';
        accountCreated.textContent = currentUser.createdAt
            ? new Date(currentUser.createdAt).toLocaleDateString()
            : 'Existing staff account';
    }

    renderPromotionStatus(currentUser || { user: 'guest', role: 'guest' });
    renderHeadNurseRequests();
    renderAdminManagementPanel();

    const headNurseRequests = document.getElementById('head-nurse-requests-panel');
    const adminManagement = document.getElementById('admin-management-panel');

    if (headNurseRequests) {
        headNurseRequests.classList.toggle('hidden', !['Head Nurse', 'System Admin'].includes(userRole));
    }
    if (adminManagement) {
        adminManagement.classList.toggle('hidden', userRole !== 'System Admin');
    }
}

async function restoreBackendSession() {
    try {
        const sessionResult = await apiRequest('/api/auth/session');
        if (sessionResult.user) enterDashboard(sessionResult.user);
        const health = await apiRequest('/api/health');
        if (!health.systemAdminConfigured) {
            const notice = document.getElementById('backend-status');
            notice.textContent = 'Initial System Admin setup is required. Follow the secure seeding steps in README.md. Existing Head Nurse accounts can still sign in and generate Nurse invitations.';
            notice.classList.remove('hidden');
        }
    } catch (err) {
        loginError.textContent = `Could not connect to the PHub backend: ${err.message}`;
    }

    if (invitationToken && !currentUser) {
        setAuthMode('register');
        document.getElementById('registration-access-code').value = invitationToken;
        registrationAccessForm.requestSubmit();
    }
}

window.addEventListener('focus', () => {
    renderCleaningState();
    if (currentUser) {
        refreshClinicalData().catch(err => {
            document.getElementById('storage-error').textContent = `Could not refresh MySQL records: ${err.message}`;
        });
        refreshBackendUser().catch(err => {
            document.getElementById('storage-error').textContent = `Could not refresh account status: ${err.message}`;
        });
    }
});

async function refreshBackendUser() {
    const result = await apiRequest('/api/auth/session');
    if (!result.user) {
        currentUser = null;
        dashboardContainer.classList.add('hidden');
        loginContainer.classList.remove('hidden');
        loginError.textContent = 'Your session has ended. Please sign in again.';
        return;
    }
    currentUser = {
        user: result.user.username,
        username: result.user.username,
        fullName: result.user.fullName,
        role: result.user.role,
        createdAt: result.user.createdAt
    };
    await refreshAccountData();
}

restoreBackendSession();

function renderRooms() {
    const tbody = document.querySelector('#rooms-table tbody');
    tbody.innerHTML = '';
    rooms.forEach(room => {
        const isWard = room.type === 'Ward' || room.beds.length > 1;
        const isExpanded = expandedWardRooms.has(room.id);
        const roomPatients = getRoomPatients(room);
        const assignedStaff = [
            ...room.staff.map(member => `${escapeHtml(member.name)} (${escapeHtml(member.role)})${member.overLimit ? ' <span class="staff-load-warning">OVER 10 POINTS</span>' : ''}`),
            ...roomPatients.flatMap(patient => patient.doctors.map(doctor =>
                `${escapeHtml(doctor.name)} (Doctor - ${escapeHtml(patient.name)})`
            ))
        ];
        const occupiedBeds = roomPatients.length;
        const roomCleaningSchedules = cleaningSchedules.filter(schedule =>
            room.beds.some(bed => bed.id === schedule.bedId)
        );
        const now = new Date();
        const cleaningBeds = room.beds.filter(bed => getBedStatus(room, bed.bedNumber) === 'Cleaning').length;
        const scheduledBeds = roomCleaningSchedules.filter(schedule =>
            new Date(schedule.start) > now ||
            roomPatients.some(patient => patient.bedId === schedule.bedId)
        ).length;
        const availableBeds = room.beds.filter(bed => getBedStatus(room, bed.bedNumber) === 'Available').length;
        const statusDisplay = isWard
            ? `<div class="ward-summary">
                <span class="status-badge status-occupied">${occupiedBeds} occupied</span>
                <span class="status-badge status-cleaning">${cleaningBeds} cleaning</span>
                <span class="status-badge status-available">${scheduledBeds} scheduled / waiting</span>
                <span class="status-badge status-available">${availableBeds} available</span>
            </div>`
            : `<span class="status-badge status-${getRoomStatus(room).toLowerCase()}">${getRoomStatus(room)}</span>`;
        const patientDisplay = isWard
            ? `${occupiedBeds} patient${occupiedBeds === 1 ? '' : 's'}`
            : roomPatients.length
                ? `<ul class="room-staff-list">${roomPatients.map(patient =>
                    `<li>${escapeHtml(patient.name)}</li>`
                ).join('')}</ul>`
                : 'None';

        tbody.innerHTML += `
            <tr>
                <td>${escapeHtml(room.number)}</td>
                <td>${escapeHtml(room.type)}</td>
                <td>${statusDisplay}</td>
                <td>${patientDisplay}</td>
                <td>${occupiedBeds}/${getRoomCapacity(room)}</td>
                <td>${assignedStaff.length
                    ? `<ul class="room-staff-list">${assignedStaff.map(member =>
                        `<li>${member}</li>`
                    ).join('')}</ul>`
                    : 'Unassigned'}</td>
                <td class="room-actions">
                    ${isWard
                        ? `<button class="btn secondary-btn ward-toggle-btn" data-room-action="toggle-beds" data-room-id="${escapeHtml(room.id)}" aria-expanded="${isExpanded}">${isExpanded ? 'Hide Beds' : 'View Beds'}</button>`
                        : ''}
                    ${['Maintenance', 'Cleaning'].includes(getRoomStatus(room)) &&
                        !cleaningSchedules.some(schedule => room.beds.some(bed => bed.id === schedule.bedId))
                        ? `<button class="btn primary-btn" data-room-action="complete-maintenance" data-room-id="${escapeHtml(room.id)}">Mark Available</button>`
                        : `<button class="btn secondary-btn" data-room-action="edit" data-room-id="${escapeHtml(room.id)}">${canChangeRoomStatus(room) ? 'Update Status' : 'Manage Staff'}</button>`}
                </td>
            </tr>
        `;

        if (isWard && isExpanded) {
            const bedCards = room.beds.map(bed => {
                const status = getBedStatus(room, bed.bedNumber);
                const patient = roomPatients.find(item => item.bedId === bed.id);
                return `<article class="ward-bed-card">
                    <div class="ward-bed-heading">
                        <h3>Bed ${escapeHtml(bed.id)}</h3>
                        <span class="status-badge status-${status.toLowerCase()}">${status}</span>
                    </div>
                    <p class="ward-bed-patient">${patient
                        ? `${escapeHtml(patient.name)} <span class="patient-acuity-label">Level ${escapeHtml(patient.acuityLevel || 1)}</span>`
                        : 'No patient assigned'}</p>
                    ${patient
                        ? `<p class="ward-bed-doctors">${patient.doctors.length
                            ? `Doctor${patient.doctors.length > 1 ? 's' : ''}: ${patient.doctors.map(doctor => escapeHtml(doctor.name)).join(', ')}`
                            : 'No doctor assigned'}</p>`
                        : ''}
                </article>`;
            }).join('');
            tbody.innerHTML += `
                <tr class="ward-details-row">
                    <td colspan="7">
                        <section class="ward-details" aria-label="${escapeHtml(room.number)} bed details">
                            <h3>${escapeHtml(room.number)} Bed Status</h3>
                            <div class="ward-bed-grid">${bedCards}</div>
                        </section>
                    </td>
                </tr>
            `;
        }
    });
}

async function completeRoomMaintenance(roomId) {
    const room = rooms.find(item => item.id === roomId);
    if (!room || !['Maintenance', 'Cleaning'].includes(getRoomStatus(room))) return;
    try {
        await apiRequest(`/api/clinical/rooms/${encodeURIComponent(roomId)}/status`, {
            method: 'PATCH',
            body: { Status: 'Available' }
        });
        await refreshClinicalData();
    } catch (err) {
        document.getElementById('storage-error').textContent = `Could not update room status: ${err.message}`;
    }
}

function toggleWardBeds(roomId) {
    if (expandedWardRooms.has(roomId)) {
        expandedWardRooms.delete(roomId);
    } else {
        expandedWardRooms.add(roomId);
    }
    renderRooms();
}

document.querySelector('#rooms-table tbody').addEventListener('click', event => {
    const button = event.target.closest('[data-room-action]');
    if (!button) return;
    const roomId = button.dataset.roomId;
    if (button.dataset.roomAction === 'toggle-beds') toggleWardBeds(roomId);
    else if (button.dataset.roomAction === 'complete-maintenance') completeRoomMaintenance(roomId);
    else if (button.dataset.roomAction === 'edit') openRoomModal(roomId);
});

function renderPatients() {
    const tbody = document.querySelector('#patients-table tbody');
    tbody.innerHTML = '';
    const displayedPatients = prioritizedPatientRoomId
        ? [...patients].sort((left, right) =>
            Number(right.room === prioritizedPatientRoomId) - Number(left.room === prioritizedPatientRoomId))
        : patients;
    displayedPatients.forEach(pat => {
        tbody.innerHTML += `
            <tr class="${pat.room === prioritizedPatientRoomId ? 'priority-patient-row' : ''}">
                <td>${escapeHtml(pat.name)}</td>
                <td>${escapeHtml(pat.room)}</td>
                <td>${escapeHtml(pat.bedId)}</td>
                <td>
                    <select class="patient-acuity-select" aria-label="Acuity level for ${escapeHtml(pat.name)}" data-patient-id="${escapeHtml(pat.id)}" data-previous-level="${escapeHtml(pat.acuityLevel || 1)}">
                        ${[1, 2, 3, 4, 5].map(level => `<option value="${level}" ${Number(pat.acuityLevel) === level ? 'selected' : ''}>Level ${level}</option>`).join('')}
                    </select>
                </td>
                <td>${pat.doctors.length
                    ? `<ul class="room-staff-list">${pat.doctors.map(doctor =>
                        `<li>${escapeHtml(doctor.name)} <button type="button" class="btn danger-btn unassign-doctor-btn" data-assignment-id="${doctor.assignmentId}">Unassign</button></li>`
                    ).join('')}</ul>`
                    : 'Unassigned'}</td>
                <td>${escapeHtml(new Date(pat.admissionDate).toLocaleString())}</td>
                <td><button type="button" class="btn danger-btn discharge-patient-btn" data-patient-id="${escapeHtml(pat.id)}">Discharge</button></td>
            </tr>
        `;
    });
}

document.querySelector('#patients-table tbody').addEventListener('click', async event => {
    const dischargeButton = event.target.closest('.discharge-patient-btn');
    const doctorButton = event.target.closest('.unassign-doctor-btn');
    try {
        if (dischargeButton) await dischargePatient(dischargeButton.dataset.patientId);
        if (doctorButton) {
            await apiRequest(`/api/clinical/doctor-assignments/${encodeURIComponent(doctorButton.dataset.assignmentId)}`, {
                method: 'DELETE'
            });
            await refreshClinicalData();
        }
    } catch (err) {
        const storageError = document.getElementById('storage-error');
        const message = `Could not update patient assignment: ${err.message}`;
        storageError.textContent = message;
        window.setTimeout(() => {
            if (storageError.textContent === message) storageError.textContent = '';
        }, 5000);
    }
});

document.querySelector('#patients-table tbody').addEventListener('change', async event => {
    const acuitySelect = event.target.closest('.patient-acuity-select');
    if (!acuitySelect) return;
    const previousLevel = acuitySelect.dataset.previousLevel || acuitySelect.value;
    try {
        const acuityResult = await apiRequest(`/api/clinical/patients/${encodeURIComponent(acuitySelect.dataset.patientId)}/acuity`, {
            method: 'PATCH',
            body: { Acuity_Level: Number(acuitySelect.value) }
        });
        acuitySelect.dataset.previousLevel = acuitySelect.value;
        await refreshClinicalData();
        showNotification(acuityResult.warning || 'Patient acuity level updated.');
    } catch (err) {
        acuitySelect.value = previousLevel;
        const storageError = document.getElementById('storage-error');
        storageError.textContent = `Could not update patient acuity: ${err.message}`;
        window.setTimeout(() => {
            if (storageError.textContent === `Could not update patient acuity: ${err.message}`) {
                storageError.textContent = '';
            }
        }, 5000);
    }
});

function renderCleaning(refreshCalendar = true) {
    const tbody = document.querySelector('#cleaning-table tbody');
    tbody.innerHTML = cleaningSchedules.length
        ? cleaningSchedules.map(item => {
            const now = new Date();
            const isUpcoming = new Date(item.start) > now;
            const isOverdue = !isUpcoming && new Date(item.end) < now;
            return `
                <tr>
                    <td>${escapeHtml(item.room)}</td>
                    <td>Bed ${escapeHtml(item.bedId || item.bedNumber)}</td>
                    <td>${escapeHtml(new Date(item.start).toLocaleString())} – ${escapeHtml(new Date(item.end).toLocaleString())}</td>
                    <td><span class="status-badge status-cleaning">${isUpcoming ? 'Scheduled · available until start' : isOverdue ? 'Overdue' : escapeHtml(item.status)}</span></td>
                    <td>
                        <button class="btn primary-btn" onclick="openCleaningTask(${item.id})">${isOverdue ? 'Reschedule' : isUpcoming ? 'Review' : 'Extend'}</button>
                        <button class="btn cleaning-complete-btn" onclick="completeCleaningFromTable(${item.id})"
                            ${isUpcoming ? 'disabled title="Cleaning cannot be completed before its scheduled start."' : ''}>
                            Mark complete
                        </button>
                    </td>
                </tr>
            `;
        }).join('')
        : '<tr><td colspan="5">No pending cleaning tasks.</td></tr>';
    if (refreshCalendar && window.phubCalendar) window.phubCalendar.refresh();
}

async function createScheduledCleaning(roomNumber, bedNumber, scheduledStart, scheduledEnd) {
    const room = rooms.find(item => item.number === roomNumber);
    if (!room || getRoomStatus(room) === 'Maintenance') {
        throw new Error('Choose a room that is not under maintenance.');
    }
    const bed = room.beds.find(item => item.bedNumber === bedNumber);
    if (!Number.isInteger(bedNumber) || bedNumber < 1 || bedNumber > getRoomCapacity(room) ||
        getBedStatus(room, bedNumber) !== 'Available' ||
        cleaningSchedules.some(schedule => bed && schedule.bedId === bed.id)) {
        throw new Error('That bed is no longer available. Choose another room or bed.');
    }

    const start = new Date(scheduledStart);
    const end = new Date(scheduledEnd);
    const now = new Date();
    now.setSeconds(0, 0);
    if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || start < now) {
        throw new Error('Choose a valid cleaning start time that is not in the past.');
    }
    if (end < new Date(start.getTime() + 48 * 60 * 60 * 1000)) {
        throw new Error('Cleaning must be scheduled for at least 48 hours.');
    }

    await apiRequest('/api/clinical/cleaning-schedules', {
        method: 'POST',
        body: { Bed_id: bed.id, start: start.toISOString(), end: end.toISOString() }
    });
    await refreshClinicalData();
    showNotification('Cleaning scheduled successfully.');
    return true;
}

function populateSelectDropdowns() {
    const patientRoomTypeSelect = document.getElementById('patient-room-type');
    const availableRoomsSelect = document.getElementById('available-rooms-select');
    const staffRoomSelect = document.getElementById('staff-room-select');
    const staffPatientSelect = document.getElementById('staff-patient-select');
    const staffNameSelect = document.getElementById('staff-name');
    const newBedRoomSelect = document.getElementById('new-bed-room');
    
    const selectedRoomType = patientRoomTypeSelect.value;
    const roomTypes = [...new Set(rooms.map(room => room.type).filter(Boolean))].sort();
    patientRoomTypeSelect.innerHTML = '<option value="">Select room type</option>' +
        roomTypes.map(type => `<option value="${escapeHtml(type)}">${escapeHtml(type)}</option>`).join('');
    patientRoomTypeSelect.value = selectedRoomType;
    availableRoomsSelect.innerHTML = '<option value="">Select a room type first</option>';
    staffRoomSelect.innerHTML = '<option value="">Select a room</option>';
    staffPatientSelect.innerHTML = '<option value="">Select an admitted patient</option>';
    staffNameSelect.innerHTML = '<option value="">Select a staff member</option>';
    newBedRoomSelect.innerHTML = '<option value="">Select a room</option>';

    rooms.forEach(room => {
        newBedRoomSelect.innerHTML += `<option value="${escapeHtml(room.id)}">${escapeHtml(room.number)}</option>`;
        if (room.beds.length) staffRoomSelect.innerHTML += `<option value="${escapeHtml(room.id)}">${escapeHtml(room.number)}</option>`;
        if (!selectedRoomType || room.type !== selectedRoomType ||
            (pendingAdmissionRoomId && room.id !== pendingAdmissionRoomId)) return;
        room.beds.forEach(bed => {
            if (getBedStatus(room, bed.bedNumber) === 'Available') {
                availableRoomsSelect.innerHTML += `<option value="${escapeHtml(bed.id)}">${escapeHtml(room.number)} - Bed ${escapeHtml(bed.id)}</option>`;
            }
        });
    });

    patients.forEach(patient => {
        staffPatientSelect.innerHTML += `<option value="${escapeHtml(patient.id)}">${escapeHtml(patient.name)} - ${escapeHtml(patient.room)} (Bed ${escapeHtml(patient.bedId)})</option>`;
    });
    const staff = staffRoleSelect.value === 'Doctor' ? doctors : nurses;
    staff.forEach(member => {
        const fullName = [member.firstName, member.middleName, member.lastName].filter(Boolean).join(' ');
        const load = staffRoleSelect.value === 'Doctor' ? '' : ` · ${Number(member.currentPoints || 0).toFixed(2)}/10 points${member.overLimit ? ' · OVER LIMIT' : ''}`;
        staffNameSelect.innerHTML += `<option value="${escapeHtml(member.id)}">${escapeHtml(fullName)} (${escapeHtml(member.id)})${escapeHtml(load)}</option>`;
    });

    availableRoomsSelect.disabled = !selectedRoomType;
    document.querySelector('#admission-form button[type="submit"]').disabled =
        availableRoomsSelect.options.length < 2;
    document.querySelector('#bed-create-form button[type="submit"]').disabled = rooms.length === 0;
    document.querySelector('#staff-assignment-submit').disabled = staff.length === 0 ||
        (staffRoleSelect.value === 'Doctor' ? patients.length === 0 : rooms.length === 0);
    updateStaffAssignmentTarget();
}

document.getElementById('patient-room-type').addEventListener('change', () => {
    pendingAdmissionRoomId = null;
    document.getElementById('available-rooms-select').value = '';
    populateSelectDropdowns();
});

function setCurrentAdmissionDate() {
    const now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    document.getElementById('patient-admission-date').value = now.toISOString().slice(0, 16);
}

document.getElementById('room-create-form').addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    try {
        await apiRequest('/api/clinical/rooms', {
            method: 'POST',
            body: {
                Room_id: document.getElementById('new-room-id').value,
                Room_type: document.getElementById('new-room-type').value
            }
        });
        form.reset();
        await refreshClinicalData();
        showNotification('Room added successfully.');
    } catch (err) {
        document.getElementById('storage-error').textContent = `Could not add room: ${err.message}`;
    }
});

document.getElementById('bed-create-form').addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    const bedIdInput = document.getElementById('new-bed-id');
    try {
        await apiRequest('/api/clinical/beds', {
            method: 'POST',
            body: {
                Bed_id: bedIdInput.value,
                Room_id: document.getElementById('new-bed-room').value,
                Status: document.getElementById('new-bed-status').value
            }
        });
        form.reset();
        await refreshClinicalData();
        showNotification('Bed added successfully.');
    } catch (err) {
        const storageError = document.getElementById('storage-error');
        const message = err.message === 'That database ID already exists.'
            ? 'That bed ID already exists. Enter a different bed ID.'
            : `Could not add bed: ${err.message}`;
        if (err.message === 'That database ID already exists.') bedIdInput.value = '';
        storageError.textContent = message;
        window.setTimeout(() => {
            if (storageError.textContent === message) storageError.textContent = '';
        }, 5000);
    }
});

document.getElementById('doctor-create-form').addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    try {
        await apiRequest('/api/clinical/doctors', {
            method: 'POST',
            body: {
                Doctor_id: document.getElementById('doctor-id').value,
                F_name: document.getElementById('doctor-first-name').value,
                M_name: document.getElementById('doctor-middle-name').value,
                L_name: document.getElementById('doctor-last-name').value,
                Phone_number: document.getElementById('doctor-phone').value,
                Email: document.getElementById('doctor-email').value
            }
        });
        form.reset();
        await refreshClinicalData();
        showNotification('Doctor added successfully.');
    } catch (err) {
        document.getElementById('storage-error').textContent = `Could not add doctor: ${err.message}`;
    }
});

document.getElementById('nurse-create-form').addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    try {
        await apiRequest('/api/clinical/nurses', {
            method: 'POST',
            body: {
                Nurse_id: document.getElementById('nurse-id').value,
                F_name: document.getElementById('nurse-first-name').value,
                M_name: document.getElementById('nurse-middle-name').value,
                L_name: document.getElementById('nurse-last-name').value,
                Phone_number: document.getElementById('nurse-phone').value,
                Email: document.getElementById('nurse-email').value,
                Shift: document.getElementById('nurse-shift').value
            }
        });
        form.reset();
        await refreshClinicalData();
        showNotification('Nurse added successfully.');
    } catch (err) {
        document.getElementById('storage-error').textContent = `Could not add nurse: ${err.message}`;
    }
});

// Room Update Modal Logic
const roomModal = document.getElementById('room-modal');
const closeModalBtn = document.getElementById('close-modal-btn');
const roomUpdateForm = document.getElementById('room-update-form');

function openRoomModal(roomId) {
    const room = rooms.find(r => r.id === roomId);
    if (!room) return;
    const floorPlanFrame = document.getElementById('floor-plan-frame');
    if (floorPlanFrame?.contentWindow) {
        floorPlanFrame.contentWindow.postMessage({ type: 'phub-floor-focus', roomId: room.id }, window.location.origin);
    }
    const canChangeStatus = canChangeRoomStatus(room);
    document.getElementById('modal-room-id').value = room.id;
    document.getElementById('modal-room-no').value = room.number;
    const statusSelect = document.getElementById('modal-room-status');
    statusSelect.value = ['Available', 'Cleaning', 'Maintenance'].includes(room.status)
        ? room.status
        : 'Available';
    document.getElementById('room-status-error').textContent = canChangeStatus
        ? ''
        : 'Room status can only be changed when the room is empty and has no active cleaning tasks.';
    document.getElementById('room-status-group').classList.toggle('hidden', !canChangeStatus);
    document.getElementById('modal-room-status').disabled = !canChangeStatus;
    document.getElementById('save-room-changes-btn').classList.toggle('hidden', !canChangeStatus);
    renderModalStaff(room);
    roomModal.classList.remove('hidden');
}

function renderModalStaff(room) {
    const list = document.getElementById('modal-staff-list');
    if (!room.staff.length) {
        list.innerHTML = '<li>No staff assigned.</li>';
        return;
    }
    list.innerHTML = room.staff.map(member => `
        <li>
            <span>${escapeHtml(member.name)} (${escapeHtml(member.role)})</span>
            <button type="button" class="btn danger-btn unassign-staff-btn" data-assignment-id="${member.assignmentId}">Unassign</button>
        </li>
    `).join('');
}

document.getElementById('modal-staff-list').addEventListener('click', event => {
    const button = event.target.closest('.unassign-staff-btn');
    if (!button) return;

    const roomId = document.getElementById('modal-room-id').value;
    const room = rooms.find(item => item.id === roomId);
    if (!room) return;

    apiRequest(`/api/clinical/nurse-assignments/${encodeURIComponent(button.dataset.assignmentId)}`, {
        method: 'DELETE'
    }).then(() => {
        showNotification('Nurse unassigned from the room.');
        return refreshClinicalData();
    }).catch(err => {
        document.getElementById('storage-error').textContent = `Could not unassign nurse: ${err.message}`;
    });
});

closeModalBtn.addEventListener('click', () => {
    roomModal.classList.add('hidden');
});

roomUpdateForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = document.getElementById('modal-room-id').value;
    const room = rooms.find(r => r.id === id);
    if (!room) return;
    if (!canChangeRoomStatus(room)) {
        document.getElementById('room-status-error').textContent = 'Room status can only be changed when the room is empty and has no active cleaning tasks.';
        document.getElementById('room-status-group').classList.add('hidden');
        renderAll();
        return;
    }

    const newStatus = document.getElementById('modal-room-status').value;
    if (!['Available', 'Cleaning', 'Maintenance'].includes(newStatus)) {
        document.getElementById('room-status-error').textContent = 'Occupied status is set automatically when a patient is assigned to the room.';
        return;
    }

    try {
        await apiRequest(`/api/clinical/rooms/${encodeURIComponent(room.id)}/status`, {
            method: 'PATCH',
            body: { Status: newStatus }
        });
        roomModal.classList.add('hidden');
        await refreshClinicalData();
        showNotification(`Room ${room.id} status updated.`);
    } catch (err) {
        document.getElementById('room-status-error').textContent = err.message;
    }
});

// Manage Patient: Admission Flow
const admissionForm = document.getElementById('admission-form');
let patientLookupRequest = 0;

async function lookupExistingPatient() {
    const patientIdInput = document.getElementById('patient-id');
    const patientIdWarning = document.getElementById('patient-id-warning');
    const patientId = patientIdInput.value.trim();
    const requestId = ++patientLookupRequest;
    if (!patientId || !/^P\d+$/.test(patientId)) {
        patientIdWarning.classList.toggle('hidden', !patientId || /^P\d+$/.test(patientId));
        patientIdInput.setCustomValidity(patientId && !/^P\d+$/.test(patientId)
            ? 'Patient ID must start with P and contain digits only after it.'
            : '');
        return;
    }
    patientIdWarning.classList.add('hidden');
    patientIdInput.setCustomValidity('');
    try {
        const result = await apiRequest(`/api/clinical/patients/${encodeURIComponent(patientId)}/profile`);
        if (requestId !== patientLookupRequest) return;
        const patient = result.patient;
        document.getElementById('patient-first-name').value = patient.firstName || '';
        document.getElementById('patient-middle-name').value = patient.middleName || '';
        document.getElementById('patient-last-name').value = patient.lastName || '';
        document.getElementById('patient-birth-date').value = patient.birthDate || '';
        document.getElementById('patient-gender').value = patient.gender || '';
        document.getElementById('patient-address').value = patient.address || '';
        document.getElementById('patient-phone').value = patient.phoneNumber || '';
        document.getElementById('patient-emergency-contact').value = patient.emergencyContact || '';
        showNotification('Existing patient information loaded.');
    } catch (err) {
        if (requestId !== patientLookupRequest || err.message === 'Patient record not found.') return;
        document.getElementById('storage-error').textContent = `Could not look up patient: ${err.message}`;
    }
}

document.getElementById('patient-id').addEventListener('blur', lookupExistingPatient);
document.getElementById('patient-id').addEventListener('keydown', event => {
    if (event.key === 'Enter') {
        event.preventDefault();
        lookupExistingPatient();
    }
});
admissionForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
        await apiRequest('/api/clinical/patients', {
            method: 'POST',
            body: {
                Patient_id: document.getElementById('patient-id').value,
                F_name: document.getElementById('patient-first-name').value,
                M_name: document.getElementById('patient-middle-name').value,
                L_name: document.getElementById('patient-last-name').value,
                B_date: document.getElementById('patient-birth-date').value,
                Gender: document.getElementById('patient-gender').value,
                Address: document.getElementById('patient-address').value,
                Phone_number: document.getElementById('patient-phone').value,
                Emergency_contact: document.getElementById('patient-emergency-contact').value,
                Acuity_Level: Number(document.getElementById('patient-acuity-level').value),
                admission: document.getElementById('patient-admission-date').value,
                Bed_id: document.getElementById('available-rooms-select').value
            }
        });
        admissionForm.reset();
        pendingAdmissionRoomId = null;
        setCurrentAdmissionDate();
        await refreshClinicalData();
        document.getElementById('storage-error').textContent = '';
        showNotification('Patient admitted successfully.');
    } catch (err) {
        document.getElementById('storage-error').textContent = `Could not admit patient: ${err.message}`;
    }
});

// Discharge a patient; the backend creates the linked cleaning task atomically.
async function dischargePatient(patientId) {
    try {
        await apiRequest(`/api/clinical/patients/${encodeURIComponent(patientId)}/discharge`, { method: 'POST' });
        await refreshClinicalData();
        document.getElementById('storage-error').textContent = '';
        showNotification('Patient discharged. Bed sent for cleaning.');
    } catch (err) {
        document.getElementById('storage-error').textContent = `Could not discharge patient: ${err.message}`;
    }
}

// Manage Staff Flow
const staffAssignmentForm = document.getElementById('staff-assignment-form');

function updateStaffAssignmentTarget() {
    const assigningDoctor = staffRoleSelect.value === 'Doctor';
    document.getElementById('staff-room-group').classList.toggle('hidden', assigningDoctor);
    document.getElementById('staff-room-select').required = !assigningDoctor;
    document.getElementById('staff-patient-group').classList.toggle('hidden', !assigningDoctor);
    document.getElementById('staff-patient-select').required = assigningDoctor;
    document.querySelector('#staff-tab .card h3').textContent = assigningDoctor
        ? 'Assign Doctor to Patient'
        : 'Assign Nurse to Room';
    document.getElementById('staff-assignment-submit').textContent = assigningDoctor
        ? 'Assign Doctor to Patient'
        : 'Assign Nurse to Room';
}

staffRoleSelect.addEventListener('change', populateSelectDropdowns);

staffAssignmentForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const role = staffRoleSelect.value;
    const staffId = document.getElementById('staff-name').value;
    try {
        if (role === 'Doctor') {
            await apiRequest('/api/clinical/doctor-assignments', {
                method: 'POST',
                body: {
                    Doctor_id: staffId,
                    Patient_id: document.getElementById('staff-patient-select').value
                }
            });
        } else {
            const assignmentResult = await apiRequest('/api/clinical/nurse-assignments', {
                method: 'POST',
                body: {
                    Nurse_id: staffId,
                    Room_id: document.getElementById('staff-room-select').value
                }
            });
            if (assignmentResult.warning) showNotification(assignmentResult.warning);
        }
        staffAssignmentForm.reset();
        updateStaffAssignmentTarget();
        await refreshClinicalData();
        showNotification(role === 'Doctor'
            ? 'Doctor assigned to the patient.'
            : 'Nurse assigned to the room.');
    } catch (err) {
        document.getElementById('storage-error').textContent = `Could not save staff assignment: ${err.message}`;
    }
});

// Cleaning acknowledgement makes only the cleaned bed available again.
async function acknowledgeCleaning(scheduleId) {
    await apiRequest(`/api/clinical/cleaning-schedules/${encodeURIComponent(scheduleId)}/complete`, {
        method: 'POST'
    });
    await refreshClinicalData();
    showNotification('Cleaning completed. Bed is now available.');
    return true;
}

async function completeCleaningFromTable(scheduleId) {
    try {
        await acknowledgeCleaning(scheduleId);
        document.getElementById('storage-error').textContent = '';
    } catch (err) {
        document.getElementById('storage-error').textContent = `Could not complete cleaning: ${err.message}`;
    }
}

setCurrentAdmissionDate();

async function updateCleaningSchedule(scheduleId, start, end, reschedule) {
    const item = cleaningSchedules.find(schedule => schedule.id === scheduleId);
    if (!item) throw new Error('This cleaning task could not be found.');

    const wasOverdue = new Date(item.end) < new Date();
    if (reschedule !== wasOverdue) {
        throw new Error(wasOverdue
            ? 'This cleaning schedule has ended. Reschedule it with a new start and end time.'
            : 'This cleaning schedule has not ended. Extend its end time instead.');
    }

    const startDate = new Date(start);
    const endDate = new Date(end);
    let updatedStart = item.start;
    if (Number.isNaN(startDate.getTime()) || Number.isNaN(endDate.getTime()) ||
        endDate < new Date(startDate.getTime() + 48 * 60 * 60 * 1000)) {
        throw new Error('The cleaning schedule must last at least 48 hours from its start.');
    }
    if (wasOverdue) {
        const earliestStart = new Date();
        earliestStart.setSeconds(0, 0);
        if (earliestStart.getTime() < Date.now()) earliestStart.setMinutes(earliestStart.getMinutes() + 1);
        if (startDate < earliestStart) {
            throw new Error('The new cleaning start cannot be in the past.');
        }
        updatedStart = startDate.toISOString();
    } else {
        if (Math.floor(startDate.getTime() / 60000) !==
            Math.floor(new Date(item.start).getTime() / 60000) || endDate <= new Date(item.end)) {
            throw new Error('For an active cleaning task, keep the original start and extend the end time.');
        }
    }

    await apiRequest(`/api/clinical/cleaning-schedules/${encodeURIComponent(scheduleId)}`, {
        method: 'PATCH',
        body: { start: updatedStart, end: endDate.toISOString() }
    });
    await refreshClinicalData();
    showNotification(reschedule ? 'Cleaning schedule rescheduled.' : 'Cleaning schedule extended.');
    return true;
}

function openCleaningTask(scheduleId) {
    if (!window.phubCalendar) {
        document.querySelector('[data-target="cleaning-tab"]').click();
    }
    if (window.phubCalendar) window.phubCalendar.openCleaningTask(scheduleId);
}