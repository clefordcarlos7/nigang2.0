'use strict';

const express = require('express');
const svc = require('./calendar.service');

const router = express.Router();
const { HttpError } = svc;
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

function requireDates(start, end) {
  const s = new Date(start);
  const e = new Date(end);
  if (isNaN(s) || isNaN(e)) throw new HttpError(400, 'start and end must be valid ISO date-times');
  if (e <= s) throw new HttpError(400, 'end must be after start');
}

// GET /api/calendar/events?from=...&to=...&roomId=101
router.get('/events', wrap(async (req, res) => {
  const { from, to, roomId } = req.query;
  requireDates(from, to);
  res.json(await svc.listEvents({ from, to, roomId }));
}));

// GET /api/calendar/availability?roomId=101&start=...&end=...
router.get('/availability', wrap(async (req, res) => {
  const { roomId, start, end } = req.query;
  if (!roomId) throw new HttpError(400, 'roomId is required');
  requireDates(start, end);
  res.json({ roomId, available: await svc.isRoomAvailable({ roomId, start, end }) });
}));

// POST /api/calendar/assignments
// body: { roomId, roomName?, start, end, doctors?: [names] | "a, b", nurses?: [names] | "a, b", notes? }
router.post('/assignments', wrap(async (req, res) => {
  const { roomId, start, end } = req.body;
  if (!roomId) throw new HttpError(400, 'roomId is required');
  requireDates(start, end);
  res.status(201).json(await svc.createAssignment(req.body));
}));

// PATCH /api/calendar/assignments/:eventId  (dates, doctors, nurses, notes)
router.patch('/assignments/:eventId', wrap(async (req, res) => {
  const { start, end } = req.body;
  if (start || end) requireDates(start || end, end || start);
  res.json(await svc.updateAssignment(req.params.eventId, req.body));
}));

// POST /api/calendar/assignments/:eventId/done
router.post('/assignments/:eventId/done', wrap(async (req, res) => {
  res.json(await svc.markDone(req.params.eventId));
}));

// DELETE /api/calendar/assignments/:eventId
router.delete('/assignments/:eventId', wrap(async (req, res) => {
  await svc.deleteAssignment(req.params.eventId);
  res.status(204).end();
}));

module.exports = router;
