const express = require('express');
const { pool } = require('./db');
const workflowStore = require('./workflow-store');

const router = express.Router();
const roomTypes = ['Ward', 'Private', 'Semi-Private', 'Intensive Care Unit (ICU)', 'Maternity'];
const bedStatuses = ['Available', 'Occupied', 'Maintenance', 'Cleaning'];
const staffShifts = ['Morning', 'Afternoon', 'Night'];
const acuityLevels = [1, 2, 3, 4, 5];
const MAX_NURSE_POINTS = 10;

async function calculateNursePoints(executor) {
    const [roomLoads] = await executor.query(`
        SELECT na.Room_id,
               COALESCE((
                   SELECT SUM(CAST(p.Acuity_Level AS UNSIGNED))
                   FROM beds b
                   JOIN patient_assignment pa ON pa.Bed_id = b.Bed_id AND pa.discharge IS NULL
                   JOIN patients p ON p.Patient_id = pa.Patient_id
                   WHERE b.Room_id = na.Room_id
               ), 0) AS roomPoints,
               COUNT(DISTINCT na.Nurse_id) AS nurseCount
        FROM nurse_assignment na
        GROUP BY na.Room_id
    `);
    const pointsByNurse = new Map();
    for (const room of roomLoads) {
        const roomPoints = Number(room.roomPoints);
        const nurseCount = Number(room.nurseCount);
        if (!nurseCount) continue;
        const share = roomPoints / nurseCount;
        const [assignedNurses] = await executor.query(
            'SELECT Nurse_id FROM nurse_assignment WHERE Room_id = ?',
            [room.Room_id]
        );
        assignedNurses.forEach(({ Nurse_id }) => {
            pointsByNurse.set(Nurse_id, (pointsByNurse.get(Nurse_id) || 0) + share);
        });
    }
    return pointsByNurse;
}

router.use((req, res, next) => {
    if (!req.body || typeof req.body !== 'object' || Array.isArray(req.body)) req.body = {};
    next();
});

function text(value, maxLength, required = true) {
    if (typeof value !== 'string') return required ? null : '';
    const result = value.trim();
    return (!required && !result) || (result.length > 0 && result.length <= maxLength) ? result : null;
}

function isPhoneNumber(value) {
    return /^09\d{9}$/.test(value);
}

function isPatientId(value) {
    return /^P\d+$/.test(value);
}

function sqlDate(value) {
    if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value)) return null;
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return null;
    return `${value.replace('T', ' ')}:00`;
}

function displayDate(value) {
    return value instanceof Date ? value.toISOString() : value;
}

async function loadClinicalData() {
    await workflowStore.syncStartedCleaningBeds();
    const [roomRows] = await pool.query(`
        SELECT r.Room_id, r.Room_type, r.Floor, b.Bed_id, b.Status
        FROM rooms r
        LEFT JOIN beds b ON b.Room_id = r.Room_id
        ORDER BY r.Room_id, b.Bed_id
    `);
    const rooms = new Map();
    for (const row of roomRows) {
        if (!rooms.has(row.Room_id)) {
            rooms.set(row.Room_id, {
                id: row.Room_id,
                number: row.Room_id,
                type: row.Room_type,
                floor: row.Floor,
                capacity: 0,
                status: 'Available',
                beds: [],
                staff: []
            });
        }
        if (row.Bed_id) {
            const room = rooms.get(row.Room_id);
            room.beds.push({
                id: row.Bed_id,
                status: row.Status,
                bedNumber: room.beds.length + 1
            });
        }
    }

    const [patientRows] = await pool.query(`
        SELECT p.Patient_id, p.F_name, p.M_name, p.L_name,
               DATE_FORMAT(p.B_date, '%Y-%m-%d') AS B_date, p.Gender,
               p.Address, p.Phone_number, p.Emergency_contact, p.Acuity_Level,
               DATE_FORMAT(pa.admission, '%Y-%m-%dT%H:%i:%s') AS admission,
               pa.Bed_id, b.Room_id
        FROM patient_assignment pa
        JOIN patients p ON p.Patient_id = pa.Patient_id
        JOIN beds b ON b.Bed_id = pa.Bed_id
        WHERE pa.discharge IS NULL
        ORDER BY pa.admission DESC, p.Patient_id
    `);
    const patients = patientRows.map(row => {
        const room = rooms.get(row.Room_id);
        const bed = room && room.beds.find(item => item.id === row.Bed_id);
        return {
            id: row.Patient_id,
            name: [row.F_name, row.M_name, row.L_name].filter(Boolean).join(' '),
            firstName: row.F_name,
            middleName: row.M_name || '',
            lastName: row.L_name,
            birthDate: row.B_date,
            gender: row.Gender,
            address: row.Address,
            phoneNumber: row.Phone_number || '',
            emergencyContact: row.Emergency_contact,
            acuityLevel: Number(row.Acuity_Level),
            room: row.Room_id,
            bedId: row.Bed_id,
            bedNumber: bed ? bed.bedNumber : null,
            doctors: [],
            admissionDate: displayDate(row.admission)
        };
    });
    const patientById = new Map(patients.map(patient => [patient.id, patient]));

    const [doctorRows] = await pool.query(`
        SELECT da.DoctorAssignment_id, da.Patient_id, d.Doctor_id,
               d.F_name, d.M_name, d.L_name
        FROM doctor_assignment da
        JOIN doctors d ON d.Doctor_id = da.Doctor_id
        ORDER BY da.Date, da.DoctorAssignment_id
    `);
    for (const row of doctorRows) {
        const patient = patientById.get(row.Patient_id);
        if (patient) {
            patient.doctors.push({
                id: row.Doctor_id,
                assignmentId: row.DoctorAssignment_id,
                name: [row.F_name, row.M_name, row.L_name].filter(Boolean).join(' '),
                role: 'Doctor'
            });
        }
    }

    const [nurseRows] = await pool.query(`
        SELECT na.NurseAssignment_id, na.Room_id, n.Nurse_id,
               n.F_name, n.M_name, n.L_name
        FROM nurse_assignment na
        JOIN nurses n ON n.Nurse_id = na.Nurse_id
        ORDER BY na.Date, na.NurseAssignment_id
    `);
    for (const row of nurseRows) {
        const room = rooms.get(row.Room_id);
        if (room) {
            room.staff.push({
                id: row.Nurse_id,
                assignmentId: row.NurseAssignment_id,
                name: [row.F_name, row.M_name, row.L_name].filter(Boolean).join(' '),
                role: 'Nurse'
            });
        }
    }

    const [doctors] = await pool.query(`
        SELECT Doctor_id AS id, F_name AS firstName, M_name AS middleName,
               L_name AS lastName, Phone_number AS phoneNumber, Email AS email
        FROM doctors ORDER BY L_name, F_name, Doctor_id
    `);
    const [nurses] = await pool.query(`
        SELECT Nurse_id AS id, F_name AS firstName, M_name AS middleName,
               L_name AS lastName, Phone_number AS phoneNumber, Email AS email, Shift AS shift
        FROM nurses ORDER BY L_name, F_name, Nurse_id
    `);

    for (const room of rooms.values()) {
        room.capacity = room.beds.length;
        const statuses = room.beds.map(bed => bed.status);
        room.status = statuses.length && statuses.every(status => status === 'Maintenance')
            ? 'Maintenance'
            : statuses.length && statuses.every(status => status === 'Cleaning')
                ? 'Cleaning'
                : statuses.length && statuses.every(status => status === 'Occupied')
                    ? 'Occupied'
                    : 'Available';
    }

    const loadById = await calculateNursePoints(pool);
    nurses.forEach(nurse => {
        nurse.currentPoints = loadById.get(nurse.id) || 0;
        nurse.maxPoints = MAX_NURSE_POINTS;
        nurse.overLimit = nurse.currentPoints > MAX_NURSE_POINTS;
    });
    for (const room of rooms.values()) {
        room.staff.forEach(member => {
            const nurse = nurses.find(item => item.id === member.id);
            if (nurse) {
                member.currentPoints = nurse.currentPoints;
                member.maxPoints = nurse.maxPoints;
                member.overLimit = nurse.overLimit;
            }
        });
    }
    return { rooms: [...rooms.values()], patients, doctors, nurses };
}

router.get('/', async (req, res) => {
    res.json(await loadClinicalData());
});

router.get('/cleaning-schedules', async (req, res) => {
    res.json({ schedules: await workflowStore.loadCleaningSchedules() });
});

router.post('/cleaning-schedules/import', async (req, res) => {
    const schedules = req.body.schedules;
    if (!Array.isArray(schedules) || schedules.length > 500 ||
        schedules.some(item => !item || typeof item.bedId !== 'string' ||
            !item.bedId.trim() || typeof item.start !== 'string' ||
            Number.isNaN(new Date(item.start).getTime()) || typeof item.end !== 'string' ||
            Number.isNaN(new Date(item.end).getTime()) ||
            new Date(item.end).getTime() < new Date(item.start).getTime() + 48 * 60 * 60 * 1000 ||
            (item.status && item.status !== 'Cleaning Scheduled')) ||
        new Set(schedules.map(item => item && item.bedId)).size !== schedules.length) {
        return res.status(400).json({ error: 'The saved cleaning schedule data is invalid.' });
    }
    const imported = await workflowStore.importCleaningSchedules(schedules.map(item => ({
        bedId: item.bedId.trim(),
        start: item.start,
        end: item.end,
        status: 'Cleaning Scheduled'
    })));
    res.json({ imported });
});

router.post('/cleaning-schedules', async (req, res) => {
    const bedId = text(req.body.Bed_id, 20);
    const start = typeof req.body.start === 'string' ? req.body.start : '';
    const end = typeof req.body.end === 'string' ? req.body.end : '';
    if (!bedId || Number.isNaN(new Date(start).getTime()) || Number.isNaN(new Date(end).getTime())) {
        return res.status(400).json({ error: 'Choose a bed and valid cleaning start and end times.' });
    }
    const result = await workflowStore.createCleaningSchedule({ bedId, start, end });
    if (result.error === 'bed-not-found') return res.status(404).json({ error: 'Bed not found.' });
    if (result.error) return res.status(409).json({ error: 'That bed is no longer available for cleaning.' });
    res.status(201).json({ ok: true });
});

router.patch('/cleaning-schedules/:id', async (req, res) => {
    const id = Number(req.params.id);
    const start = typeof req.body.start === 'string' ? req.body.start : '';
    const end = typeof req.body.end === 'string' ? req.body.end : '';
    if (!Number.isSafeInteger(id) || id < 1 ||
        Number.isNaN(new Date(start).getTime()) || Number.isNaN(new Date(end).getTime())) {
        return res.status(400).json({ error: 'Choose valid cleaning start and end times.' });
    }
    const result = await workflowStore.updateCleaningSchedule(id, start, end);
    if (result.error === 'not-found') return res.status(404).json({ error: 'Cleaning schedule not found.' });
    if (result.error === 'bed-occupied') return res.status(409).json({ error: 'An occupied bed cannot be rescheduled.' });
    if (result.error) return res.status(400).json({ error: 'The cleaning schedule change is not valid.' });
    res.json({ ok: true });
});

router.post('/cleaning-schedules/:id/complete', async (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id < 1) {
        return res.status(400).json({ error: 'Invalid cleaning schedule ID.' });
    }
    const result = await workflowStore.completeCleaningSchedule(id);
    if (result.error === 'not-found') return res.status(404).json({ error: 'Cleaning schedule not found.' });
    if (result.error === 'bed-occupied') return res.status(409).json({ error: 'An occupied bed cannot be marked ready.' });
    res.json({ ok: true });
});

router.post('/rooms', async (req, res) => {
    if (req.account.role !== 'System Admin') {
        return res.status(403).json({ error: 'Only a System Admin can add rooms.' });
    }
    const id = text(req.body.Room_id, 50);
    const type = text(req.body.Room_type, 50);
    if (!id || !type || !roomTypes.includes(type)) {
        return res.status(400).json({ error: 'Enter a room ID and a valid room type.' });
    }
    await pool.execute('INSERT INTO rooms (Room_id, Room_type) VALUES (?, ?)', [id, type]);
    res.status(201).json({ ok: true });
});

router.post('/beds', async (req, res) => {
    if (!['Head Nurse', 'System Admin'].includes(req.account.role)) {
        return res.status(403).json({ error: 'Only a Head Nurse or System Admin can add beds.' });
    }
    const id = text(req.body.Bed_id, 20);
    const roomId = text(req.body.Room_id, 50);
    const status = text(req.body.Status, 20);
    if (!id || !roomId || !status || !bedStatuses.includes(status) || status === 'Occupied') {
        return res.status(400).json({ error: 'Enter a bed ID, room ID, and an allowed initial status. Beds become occupied through patient admission.' });
    }
    await pool.execute(
        'INSERT INTO beds (Bed_id, Status, Room_id) VALUES (?, ?, ?)',
        [id, status, roomId]
    );
    res.status(201).json({ ok: true });
});

router.patch('/rooms/:id/status', async (req, res) => {
    const roomId = text(req.params.id, 50);
    const status = text(req.body.Status, 20);
    if (!roomId || !bedStatuses.includes(status) || status === 'Occupied') {
        return res.status(400).json({ error: 'Choose Available, Maintenance, or Cleaning for the room.' });
    }
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        const [beds] = await connection.execute(
            'SELECT Bed_id FROM beds WHERE Room_id = ? FOR UPDATE',
            [roomId]
        );
        if (!beds.length) {
            await connection.rollback();
            return res.status(404).json({ error: 'Room has no beds to update.' });
        }
        const [occupied] = await connection.execute(
            `SELECT 1 FROM patient_assignment pa
             JOIN beds b ON b.Bed_id = pa.Bed_id
             WHERE b.Room_id = ? AND pa.discharge IS NULL LIMIT 1`,
            [roomId]
        );
        if (occupied.length) {
            await connection.rollback();
            return res.status(409).json({ error: 'A room with admitted patients cannot have its bed statuses changed as a group.' });
        }
        const [schedules] = await connection.execute(
            `SELECT s.id, s.Bed_id AS bedId
             FROM phub_cleaning_schedules s
             JOIN beds b ON b.Bed_id = s.Bed_id
             WHERE b.Room_id = ?
             FOR UPDATE`,
            [roomId]
        );
        if (schedules.length && status !== 'Cleaning') {
            await connection.rollback();
            return res.status(409).json({ error: 'Complete or reschedule active cleaning tasks before changing the room status.' });
        }
        await connection.execute('UPDATE beds SET Status = ? WHERE Room_id = ?', [status, roomId]);
        if (status === 'Cleaning') {
            const scheduledBedIds = new Set(schedules.map(item => item.bedId));
            for (const bed of beds) {
                if (scheduledBedIds.has(bed.Bed_id)) {
                    await connection.execute(
                        `UPDATE phub_cleaning_schedules
                         SET starts_at = DATE_FORMAT(UTC_TIMESTAMP(), '%Y-%m-%d %H:%i:00'),
                             ends_at = GREATEST(ends_at,
                                 DATE_ADD(DATE_FORMAT(UTC_TIMESTAMP(), '%Y-%m-%d %H:%i:00'), INTERVAL 48 HOUR)),
                             status = 'Cleaning Scheduled'
                         WHERE Bed_id = ?`,
                        [bed.Bed_id]
                    );
                } else {
                    await connection.execute(
                        `INSERT INTO phub_cleaning_schedules (Bed_id, starts_at, ends_at, status)
                         VALUES (?, DATE_FORMAT(UTC_TIMESTAMP(), '%Y-%m-%d %H:%i:00'),
                                 DATE_ADD(DATE_FORMAT(UTC_TIMESTAMP(), '%Y-%m-%d %H:%i:00'), INTERVAL 48 HOUR),
                                 'Cleaning Scheduled')`,
                        [bed.Bed_id]
                    );
                }
            }
        }
        await connection.commit();
        res.json({ ok: true });
    } catch (err) {
        await connection.rollback();
        throw err;
    } finally {
        connection.release();
    }
});

router.patch('/beds/:id/status', async (req, res) => {
    const bedId = text(req.params.id, 20);
    const status = text(req.body.Status, 20);
    if (!bedId || !bedStatuses.includes(status) || status === 'Occupied') {
        return res.status(400).json({ error: 'Choose Available, Maintenance, or Cleaning for the bed.' });
    }
    const [active] = await pool.execute(
        'SELECT PatientAssignment_id FROM patient_assignment WHERE Bed_id = ? AND discharge IS NULL LIMIT 1',
        [bedId]
    );
    if (active.length) return res.status(409).json({ error: 'An occupied bed cannot be changed until its patient is discharged.' });
    const [schedules] = await pool.execute(
        'SELECT id FROM phub_cleaning_schedules WHERE Bed_id = ? LIMIT 1',
        [bedId]
    );
    if (schedules.length && status !== 'Cleaning') {
        return res.status(409).json({ error: 'Complete or reschedule this cleaning task before changing the bed status.' });
    }
    if (status === 'Cleaning' && !schedules.length) {
        const start = new Date();
        start.setSeconds(0, 0);
        const end = new Date(start.getTime() + 48 * 60 * 60 * 1000);
        const result = await workflowStore.createCleaningSchedule({
            bedId,
            start: start.toISOString(),
            end: end.toISOString()
        });
        if (result.error) return res.status(409).json({ error: 'That bed is no longer available for cleaning.' });
        return res.json({ ok: true });
    }
    const [result] = await pool.execute('UPDATE beds SET Status = ? WHERE Bed_id = ?', [status, bedId]);
    if (!result.affectedRows) return res.status(404).json({ error: 'Bed not found.' });
    res.json({ ok: true });
});

router.get('/patients/:id/profile', async (req, res) => {
    const patientId = text(req.params.id, 50);
    if (!patientId || !isPatientId(patientId)) return res.status(400).json({ error: 'Patient ID must start with P and contain digits only after it.' });
    const [rows] = await pool.execute(
        `SELECT Patient_id AS id, F_name AS firstName, M_name AS middleName,
                L_name AS lastName, DATE_FORMAT(B_date, '%Y-%m-%d') AS birthDate,
                Gender AS gender, Address AS address, Phone_number AS phoneNumber,
                Emergency_contact AS emergencyContact
         FROM patients
         WHERE Patient_id = ?`,
        [patientId]
    );
    if (!rows.length) return res.status(404).json({ error: 'Patient record not found.' });
    res.json({ patient: { ...rows[0], middleName: rows[0].middleName || '', phoneNumber: rows[0].phoneNumber || '' } });
});

router.post('/patients', async (req, res) => {
    const patientId = text(req.body.Patient_id, 50);
    const firstName = text(req.body.F_name, 50);
    const middleName = text(req.body.M_name, 50, false);
    const lastName = text(req.body.L_name, 50);
    const birthDate = text(req.body.B_date, 10);
    const gender = text(req.body.Gender, 10);
    const address = text(req.body.Address, 150);
    const phone = text(req.body.Phone_number, 20, false);
    const emergencyContact = text(req.body.Emergency_contact, 20);
    const bedId = text(req.body.Bed_id, 20);
    const acuityLevel = Number(req.body.Acuity_Level);
    const admission = req.body.admission ? sqlDate(req.body.admission) : null;
    const birth = birthDate && new Date(`${birthDate}T00:00:00Z`);
    const validBirthDate = birth && !Number.isNaN(birth.getTime()) &&
        birth.toISOString().slice(0, 10) === birthDate && birth <= new Date();
    if (!patientId || !isPatientId(patientId) || !firstName || middleName === null || !lastName || !validBirthDate ||
        !['Male', 'Female', 'Other'].includes(gender) || !address ||
        phone === null || (phone && !isPhoneNumber(phone)) ||
        !emergencyContact || !isPhoneNumber(emergencyContact) ||
        !bedId || !acuityLevels.includes(acuityLevel) ||
        (req.body.admission && !admission)) {
        return res.status(400).json({ error: 'Complete all required patient and admission fields with valid values.' });
    }

    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        const [beds] = await connection.execute(
            'SELECT Status FROM beds WHERE Bed_id = ? FOR UPDATE',
            [bedId]
        );
        if (!beds.length) {
            await connection.rollback();
            return res.status(404).json({ error: 'Selected bed was not found.' });
        }
        const [startedCleaning] = await connection.execute(
            `SELECT id FROM phub_cleaning_schedules
             WHERE Bed_id = ? AND starts_at <= UTC_TIMESTAMP(3)
             LIMIT 1 FOR UPDATE`,
            [bedId]
        );
        if (beds[0].Status === 'Available' && startedCleaning.length) {
            await connection.execute("UPDATE beds SET Status = 'Cleaning' WHERE Bed_id = ?", [bedId]);
            await connection.commit();
            return res.status(409).json({ error: 'Selected bed is scheduled for cleaning and is no longer available.' });
        }
        if (beds[0].Status !== 'Available') {
            await connection.rollback();
            return res.status(409).json({ error: 'Selected bed is no longer available.' });
        }
        const [existingPatients] = await connection.execute(
            'SELECT Patient_id FROM patients WHERE Patient_id = ? FOR UPDATE',
            [patientId]
        );
        if (existingPatients.length) {
            const [activeAssignments] = await connection.execute(
                'SELECT PatientAssignment_id FROM patient_assignment WHERE Patient_id = ? AND discharge IS NULL LIMIT 1',
                [patientId]
            );
            if (activeAssignments.length) {
                await connection.rollback();
                return res.status(409).json({ error: 'This patient is already admitted.' });
            }
            await connection.execute(
                `UPDATE patients
                 SET F_name = ?, M_name = ?, L_name = ?, B_date = ?, Gender = ?,
                     Address = ?, Phone_number = ?, Emergency_contact = ?, Acuity_Level = ?
                 WHERE Patient_id = ?`,
                [firstName, middleName || null, lastName, birthDate, gender, address,
                    phone || null, emergencyContact, acuityLevel, patientId]
            );
        } else {
            await connection.execute(
                `INSERT INTO patients
                 (Patient_id, F_name, M_name, L_name, B_date, Gender, Address, Phone_number, Emergency_contact, Acuity_Level)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [patientId, firstName, middleName || null, lastName, birthDate, gender, address, phone || null, emergencyContact, acuityLevel]
            );
        }
        if (admission) {
            await connection.execute(
                'INSERT INTO patient_assignment (Patient_id, admission, Bed_id) VALUES (?, ?, ?)',
                [patientId, admission, bedId]
            );
        } else {
            await connection.execute(
                'INSERT INTO patient_assignment (Patient_id, Bed_id) VALUES (?, ?)',
                [patientId, bedId]
            );
        }
        await connection.execute('UPDATE beds SET Status = ? WHERE Bed_id = ?', ['Occupied', bedId]);
        await connection.commit();
        res.status(201).json({ ok: true });
    } catch (err) {
        await connection.rollback();
        throw err;
    } finally {
        connection.release();
    }
});

router.post('/patients/:id/discharge', async (req, res) => {
    const patientId = text(req.params.id, 50);
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        const [assignments] = await connection.execute(
            'SELECT Bed_id FROM patient_assignment WHERE Patient_id = ? AND discharge IS NULL FOR UPDATE',
            [patientId]
        );
        if (!assignments.length) {
            await connection.rollback();
            return res.status(404).json({ error: 'Active patient admission not found.' });
        }
        await connection.execute(
            'UPDATE patient_assignment SET discharge = CURRENT_TIMESTAMP WHERE Patient_id = ? AND discharge IS NULL',
            [patientId]
        );
        await connection.execute(
            'DELETE FROM doctor_assignment WHERE Patient_id = ?',
            [patientId]
        );
        const bedId = assignments[0].Bed_id;
        const [cleaning] = await connection.execute(
            'SELECT id, ends_at FROM phub_cleaning_schedules WHERE Bed_id = ? FOR UPDATE',
            [bedId]
        );
        if (cleaning.length) {
            await connection.execute(
                `UPDATE phub_cleaning_schedules
                 SET starts_at = DATE_FORMAT(UTC_TIMESTAMP(), '%Y-%m-%d %H:%i:00'),
                     ends_at = GREATEST(ends_at,
                         DATE_ADD(DATE_FORMAT(UTC_TIMESTAMP(), '%Y-%m-%d %H:%i:00'), INTERVAL 48 HOUR)),
                     status = 'Cleaning Scheduled'
                 WHERE id = ?`,
                [cleaning[0].id]
            );
        } else {
            await connection.execute(
                `INSERT INTO phub_cleaning_schedules (Bed_id, starts_at, ends_at, status)
                 VALUES (?, DATE_FORMAT(UTC_TIMESTAMP(), '%Y-%m-%d %H:%i:00'),
                         DATE_ADD(DATE_FORMAT(UTC_TIMESTAMP(), '%Y-%m-%d %H:%i:00'), INTERVAL 48 HOUR),
                         'Cleaning Scheduled')`,
                [bedId]
            );
        }
        await connection.execute(
            'UPDATE beds SET Status = ? WHERE Bed_id = ?',
            ['Cleaning', bedId]
        );
        await connection.commit();
        res.json({ ok: true, Bed_id: bedId });
    } catch (err) {
        await connection.rollback();
        throw err;
    } finally {
        connection.release();
    }
});

router.patch('/patients/:id/acuity', async (req, res) => {
    const patientId = text(req.params.id, 50);
    const acuityLevel = Number(req.body.Acuity_Level);
    if (!patientId || !acuityLevels.includes(acuityLevel)) {
        return res.status(400).json({ error: 'Choose an acuity level from 1 to 5.' });
    }
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        const [patientRows] = await connection.execute(
            'SELECT Patient_id FROM patients WHERE Patient_id = ? FOR UPDATE',
            [patientId]
        );
        if (!patientRows.length) {
            await connection.rollback();
            return res.status(404).json({ error: 'Patient not found.' });
        }
        await connection.execute('UPDATE patients SET Acuity_Level = ? WHERE Patient_id = ?', [acuityLevel, patientId]);
        const loadByNurse = await calculateNursePoints(connection);
        const overloaded = [...loadByNurse.entries()].filter(([, points]) => points > MAX_NURSE_POINTS);
        await connection.commit();
        res.json({
            ok: true,
            Acuity_Level: acuityLevel,
            warning: overloaded.length
                ? 'One or more assigned nurses are now above the 10-point recommendation.'
                : null
        });
    } catch (err) {
        await connection.rollback();
        throw err;
    } finally {
        connection.release();
    }
});

function staffFields(body, isNurse) {
    const fields = {
        id: text(body[isNurse ? 'Nurse_id' : 'Doctor_id'], 50),
        firstName: text(body.F_name, 50),
        middleName: text(body.M_name, 50, false),
        lastName: text(body.L_name, 50),
        phone: text(body.Phone_number, 20, false),
        email: text(body.Email, 150),
        shift: isNurse ? text(body.Shift, 20) : null
    };
    if (!fields.id || !fields.firstName || fields.middleName === null || !fields.lastName ||
        fields.phone === null || (fields.phone && !isPhoneNumber(fields.phone)) ||
        !fields.email || (isNurse && !staffShifts.includes(fields.shift))) {
        return null;
    }
    return fields;
}

function staffValues(fields) {
    return [
        fields.id, fields.firstName, fields.middleName || null, fields.lastName,
        fields.phone || null, fields.email
    ];
}

router.post('/doctors', async (req, res) => {
    const fields = staffFields(req.body, false);
    if (!fields) return res.status(400).json({ error: 'Complete all required doctor fields.' });
    await pool.execute(
        'INSERT INTO doctors (Doctor_id, F_name, M_name, L_name, Phone_number, Email) VALUES (?, ?, ?, ?, ?, ?)',
        staffValues(fields)
    );
    res.status(201).json({ ok: true });
});

router.delete('/doctors/:id', async (req, res) => {
    if (req.account.role !== 'System Admin') {
        return res.status(403).json({ error: 'Only a System Admin can remove doctors.' });
    }
    const doctorId = text(req.params.id, 50);
    if (!doctorId) return res.status(400).json({ error: 'Invalid doctor ID.' });

    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        await connection.execute('DELETE FROM doctor_assignment WHERE Doctor_id = ?', [doctorId]);
        const [result] = await connection.execute('DELETE FROM doctors WHERE Doctor_id = ?', [doctorId]);
        if (!result.affectedRows) {
            await connection.rollback();
            return res.status(404).json({ error: 'Doctor not found.' });
        }
        await connection.commit();
        res.json({ ok: true });
    } catch (err) {
        await connection.rollback();
        throw err;
    } finally {
        connection.release();
    }
});

router.post('/nurses', async (req, res) => {
    const fields = staffFields(req.body, true);
    if (!fields) return res.status(400).json({ error: 'Complete all required nurse fields and choose a valid shift.' });
    await pool.execute(
        'INSERT INTO nurses (Nurse_id, F_name, M_name, L_name, Phone_number, Email, Shift) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [...staffValues(fields), fields.shift]
    );
    res.status(201).json({ ok: true });
});

router.delete('/nurses/:id', async (req, res) => {
    if (req.account.role !== 'System Admin') {
        return res.status(403).json({ error: 'Only a System Admin can remove nurses.' });
    }
    const nurseId = text(req.params.id, 50);
    if (!nurseId) return res.status(400).json({ error: 'Invalid nurse ID.' });

    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        await connection.execute('DELETE FROM nurse_assignment WHERE Nurse_id = ?', [nurseId]);
        const [result] = await connection.execute('DELETE FROM nurses WHERE Nurse_id = ?', [nurseId]);
        if (!result.affectedRows) {
            await connection.rollback();
            return res.status(404).json({ error: 'Nurse not found.' });
        }
        await connection.commit();
        res.json({ ok: true });
    } catch (err) {
        await connection.rollback();
        throw err;
    } finally {
        connection.release();
    }
});

router.get('/nurse-suggestions/:roomId', async (req, res) => {
    const roomId = text(req.params.roomId, 50);
    if (!roomId) return res.status(400).json({ error: 'Invalid room ID.' });
    const [roomRows] = await pool.execute('SELECT Room_id FROM rooms WHERE Room_id = ?', [roomId]);
    if (!roomRows.length) return res.status(404).json({ error: 'Room not found.' });
    const [suggestions] = await pool.execute(
        `SELECT Nurse_id AS id, Nurse_name AS name, Current_points AS currentPoints,
                Active_patient_count AS activePatientCount, Assigned_room_count AS assignedRoomCount,
                Proximity_group AS proximityGroup, Floor_distance AS floorDistance
         FROM nurse_room_suggestions
         WHERE Room_id = ?
         ORDER BY Proximity_group, Floor_distance, Current_points, Nurse_name`,
        [roomId]
    );
    res.json({ nurses: suggestions.map(nurse => ({ ...nurse, currentPoints: Number(nurse.currentPoints), maxPoints: MAX_NURSE_POINTS })) });
});

router.post('/nurse-assignments', async (req, res) => {
    const nurseId = text(req.body.Nurse_id, 50);
    const roomId = text(req.body.Room_id, 50);
    if (!nurseId || !roomId) return res.status(400).json({ error: 'Choose a nurse and a room.' });
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        const [existing] = await connection.execute(
        'SELECT NurseAssignment_id FROM nurse_assignment WHERE Nurse_id = ? AND Room_id = ? LIMIT 1',
        [nurseId, roomId]
        );
        if (existing.length) {
            await connection.rollback();
            return res.status(409).json({ error: 'That nurse is already assigned to this room.' });
        }
        await connection.execute(
            'INSERT INTO nurse_assignment (Room_id, Nurse_id) VALUES (?, ?)',
            [roomId, nurseId]
        );
        const loadByNurse = await calculateNursePoints(connection);
        const currentPoints = loadByNurse.get(nurseId) || 0;
        await connection.commit();
        res.status(201).json({
            ok: true,
            currentPoints,
            maxPoints: MAX_NURSE_POINTS,
            warning: currentPoints > MAX_NURSE_POINTS
                ? `This nurse is above the recommended ${MAX_NURSE_POINTS}-point load.`
                : null
        });
    } catch (err) {
        await connection.rollback();
        throw err;
    } finally {
        connection.release();
    }
});

router.delete('/nurse-assignments/:id', async (req, res) => {
    const assignmentId = Number(req.params.id);
    if (!Number.isSafeInteger(assignmentId) || assignmentId < 1) {
        return res.status(400).json({ error: 'Invalid nurse assignment ID.' });
    }
    const [result] = await pool.execute(
        'DELETE FROM nurse_assignment WHERE NurseAssignment_id = ?',
        [assignmentId]
    );
    if (!result.affectedRows) return res.status(404).json({ error: 'Nurse assignment not found.' });
    res.json({ ok: true });
});

router.post('/doctor-assignments', async (req, res) => {
    const doctorId = text(req.body.Doctor_id, 50);
    const patientId = text(req.body.Patient_id, 50);
    if (!doctorId || !patientId) return res.status(400).json({ error: 'Choose a doctor and an admitted patient.' });
    const [existing] = await pool.execute(
        'SELECT DoctorAssignment_id FROM doctor_assignment WHERE Doctor_id = ? AND Patient_id = ? LIMIT 1',
        [doctorId, patientId]
    );
    if (existing.length) return res.status(409).json({ error: 'That doctor is already assigned to this patient.' });
    const [activePatient] = await pool.execute(
        'SELECT PatientAssignment_id FROM patient_assignment WHERE Patient_id = ? AND discharge IS NULL LIMIT 1',
        [patientId]
    );
    if (!activePatient.length) return res.status(409).json({ error: 'Only admitted patients can be assigned a doctor.' });
    await pool.execute(
        'INSERT INTO doctor_assignment (Doctor_id, Patient_id) VALUES (?, ?)',
        [doctorId, patientId]
    );
    res.status(201).json({ ok: true });
});

router.delete('/doctor-assignments/:id', async (req, res) => {
    const assignmentId = Number(req.params.id);
    if (!Number.isSafeInteger(assignmentId) || assignmentId < 1) {
        return res.status(400).json({ error: 'Invalid doctor assignment ID.' });
    }
    const [result] = await pool.execute(
        'DELETE FROM doctor_assignment WHERE DoctorAssignment_id = ?',
        [assignmentId]
    );
    if (!result.affectedRows) return res.status(404).json({ error: 'Doctor assignment not found.' });
    res.json({ ok: true });
});

router.use((err, req, res, next) => {
    if (err.code === 'ER_DUP_ENTRY') {
        return res.status(409).json({ error: 'That database ID already exists.' });
    }
    if (err.code === 'ER_NO_REFERENCED_ROW_2') {
        return res.status(400).json({ error: 'A selected room, bed, patient, or staff record does not exist.' });
    }
    if (err.code === 'ER_DATA_TOO_LONG' || err.code === 'ER_TRUNCATED_WRONG_VALUE_FOR_FIELD') {
        return res.status(400).json({ error: 'One or more values exceed the database field format or length.' });
    }
    next(err);
});

module.exports = router;
