const { pool } = require('./db');

function mysqlDate(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) throw new Error('A workflow record has an invalid timestamp.');
    return date.toISOString().slice(0, 23).replace('T', ' ');
}

async function importIfEmpty(connection, tableName, rows, insertSql, valuesForRow) {
    const [counts] = await connection.query(`SELECT COUNT(*) AS count FROM \`${tableName}\``);
    if (Number(counts[0].count) !== 0 || rows.length === 0) return;
    for (const row of rows) {
        await connection.execute(insertSql, valuesForRow(row));
    }
}

async function migrateLegacyFiles({ accounts, invitations, promotionRequests, auditEvents }) {
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        await importIfEmpty(
            connection,
            'phub_accounts',
            accounts,
            `INSERT INTO phub_accounts
             (username, full_name, role, status, salt, password_hash, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            item => [
                item.username, item.fullName, item.role, item.status, item.salt,
                item.passwordHash, mysqlDate(item.createdAt)
            ]
        );
        await importIfEmpty(
            connection,
            'phub_invitations',
            invitations,
            `INSERT INTO phub_invitations
             (token_hash, created_at, expires_at, created_by, used_at, used_by)
             VALUES (?, ?, ?, ?, ?, ?)`,
            item => [
                item.tokenHash, mysqlDate(item.createdAt), mysqlDate(item.expiresAt),
                item.createdBy, item.usedAt ? mysqlDate(item.usedAt) : null, item.usedBy || null
            ]
        );
        await importIfEmpty(
            connection,
            'phub_promotion_requests',
            promotionRequests,
            `INSERT INTO phub_promotion_requests
             (id, requester_username, requester_name, requested_role, status, submitted_at,
              reviewed_by, decision, decision_date)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            item => [
                item.id, item.requesterUsername, item.requesterName, item.requestedRole,
                item.status, mysqlDate(item.submittedAt), item.reviewedBy || null,
                item.decision || null, item.decisionDate ? mysqlDate(item.decisionDate) : null
            ]
        );
        const recentAuditEvents = auditEvents.slice(-1000);
        await importIfEmpty(
            connection,
            'phub_security_audit',
            recentAuditEvents,
            `INSERT INTO phub_security_audit (id, \`at\`, event_type, details)
             VALUES (?, ?, ?, ?)`,
            item => [
                item.id, mysqlDate(item.at), item.eventType, JSON.stringify(item.details || {})
            ]
        );
        await connection.commit();
    } catch (err) {
        await connection.rollback();
        throw err;
    } finally {
        connection.release();
    }
}

async function loadAccounts() {
    const [rows] = await pool.query(`
        SELECT username, full_name AS fullName, role, status, salt,
               password_hash AS passwordHash,
               DATE_FORMAT(created_at, '%Y-%m-%dT%H:%i:%s.%fZ') AS createdAt
        FROM phub_accounts
        ORDER BY username
    `);
    return rows;
}

async function insertAccount(account) {
    await pool.execute(
        `INSERT INTO phub_accounts
         (username, full_name, role, status, salt, password_hash, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
            account.username, account.fullName, account.role, account.status,
            account.salt, account.passwordHash, mysqlDate(account.createdAt)
        ]
    );
}

async function deleteAccount(username) {
    const [result] = await pool.execute('DELETE FROM phub_accounts WHERE username = ?', [username]);
    return result.affectedRows > 0;
}

async function insertAuditEvent(event) {
    await pool.execute(
        'INSERT INTO phub_security_audit (id, `at`, event_type, details) VALUES (?, ?, ?, ?)',
        [event.id, mysqlDate(event.at), event.eventType, JSON.stringify(event.details)]
    );
    await pool.query(`
        DELETE FROM phub_security_audit
        WHERE id NOT IN (
            SELECT id FROM (
                SELECT id FROM phub_security_audit
                ORDER BY \`at\` DESC, id DESC
                LIMIT 1000
            ) AS recent_events
        )
    `);
}

async function insertInvitation(invitation) {
    await pool.execute(
        `INSERT INTO phub_invitations
         (token_hash, created_at, expires_at, created_by, used_at, used_by)
         VALUES (?, ?, ?, ?, NULL, NULL)`,
        [
            invitation.tokenHash, mysqlDate(invitation.createdAt), mysqlDate(invitation.expiresAt),
            invitation.createdBy
        ]
    );
}

async function redeemInvitation(invitationHash, account) {
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        const [invitations] = await connection.execute(
            `SELECT token_hash FROM phub_invitations
             WHERE token_hash = ? AND used_at IS NULL AND expires_at > UTC_TIMESTAMP(3)
             FOR UPDATE`,
            [invitationHash]
        );
        if (!invitations.length) {
            await connection.rollback();
            return 'invitation';
        }
        const [existing] = await connection.execute(
            'SELECT username FROM phub_accounts WHERE username = ?',
            [account.username]
        );
        if (existing.length) {
            await connection.rollback();
            return 'username';
        }
        await connection.execute(
            `INSERT INTO phub_accounts
             (username, full_name, role, status, salt, password_hash, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [
                account.username, account.fullName, account.role, account.status, account.salt,
                account.passwordHash, mysqlDate(account.createdAt)
            ]
        );
        await connection.execute(
            `UPDATE phub_invitations
             SET used_at = UTC_TIMESTAMP(3), used_by = ?
             WHERE token_hash = ?`,
            [account.username, invitationHash]
        );
        await connection.commit();
        return 'created';
    } catch (err) {
        await connection.rollback();
        throw err;
    } finally {
        connection.release();
    }
}

async function listValidInvitations() {
    const [rows] = await pool.query(`
        SELECT DATE_FORMAT(created_at, '%Y-%m-%dT%H:%i:%s.%fZ') AS createdAt,
               DATE_FORMAT(expires_at, '%Y-%m-%dT%H:%i:%s.%fZ') AS expiresAt,
               created_by AS createdBy
        FROM phub_invitations
        WHERE used_at IS NULL AND expires_at > UTC_TIMESTAMP(3)
        ORDER BY created_at DESC
    `);
    return rows;
}

async function validateInvitation(tokenHash) {
    const [rows] = await pool.execute(`
        SELECT DATE_FORMAT(expires_at, '%Y-%m-%dT%H:%i:%s.%fZ') AS expiresAt,
               created_by AS createdBy
        FROM phub_invitations
        WHERE token_hash = ? AND used_at IS NULL AND expires_at > UTC_TIMESTAMP(3)
        LIMIT 1
    `, [tokenHash]);
    return rows[0] || null;
}

async function createPromotionRequest(request) {
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        const [accounts] = await connection.execute(
            'SELECT username FROM phub_accounts WHERE username = ? FOR UPDATE',
            [request.requesterUsername]
        );
        if (!accounts.length) {
            await connection.rollback();
            return false;
        }
        const [pending] = await connection.execute(
            `SELECT id FROM phub_promotion_requests
             WHERE requester_username = ? AND status = 'Pending'
             LIMIT 1 FOR UPDATE`,
            [request.requesterUsername]
        );
        if (pending.length) {
            await connection.rollback();
            return false;
        }
        await connection.execute(
            `INSERT INTO phub_promotion_requests
             (id, requester_username, requester_name, requested_role, status, submitted_at,
              reviewed_by, decision, decision_date)
             VALUES (?, ?, ?, ?, ?, ?, NULL, NULL, NULL)`,
            [
                request.id, request.requesterUsername, request.requesterName,
                request.requestedRole, request.status, mysqlDate(request.submittedAt)
            ]
        );
        await connection.commit();
        return true;
    } catch (err) {
        await connection.rollback();
        throw err;
    } finally {
        connection.release();
    }
}

async function listPendingPromotionRequests() {
    const [rows] = await pool.query(`
        SELECT id, requester_username AS requesterUsername,
               requester_name AS requesterName, requested_role AS requestedRole, status,
               DATE_FORMAT(submitted_at, '%Y-%m-%dT%H:%i:%s.%fZ') AS submittedAt,
               reviewed_by AS reviewedBy, decision,
               DATE_FORMAT(decision_date, '%Y-%m-%dT%H:%i:%s.%fZ') AS decisionDate
        FROM phub_promotion_requests
        WHERE status = 'Pending'
        ORDER BY submitted_at
    `);
    return rows;
}

async function latestPromotionRequest(username) {
    const [rows] = await pool.execute(`
        SELECT id, requester_username AS requesterUsername,
               requester_name AS requesterName, requested_role AS requestedRole, status,
               DATE_FORMAT(submitted_at, '%Y-%m-%dT%H:%i:%s.%fZ') AS submittedAt,
               reviewed_by AS reviewedBy, decision,
               DATE_FORMAT(decision_date, '%Y-%m-%dT%H:%i:%s.%fZ') AS decisionDate
        FROM phub_promotion_requests
        WHERE requester_username = ?
        ORDER BY submitted_at DESC
        LIMIT 1
    `, [username]);
    return rows[0] || null;
}

async function decidePromotionRequest(id, decision, reviewer) {
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        const [rows] = await connection.execute(`
            SELECT id, requester_username AS requesterUsername,
                   requester_name AS requesterName, requested_role AS requestedRole, status,
                   DATE_FORMAT(submitted_at, '%Y-%m-%dT%H:%i:%s.%fZ') AS submittedAt,
                   reviewed_by AS reviewedBy, decision,
                   DATE_FORMAT(decision_date, '%Y-%m-%dT%H:%i:%s.%fZ') AS decisionDate
            FROM phub_promotion_requests
            WHERE id = ? AND status = 'Pending'
            FOR UPDATE
        `, [id]);
        if (!rows.length) {
            await connection.rollback();
            return { error: 'not-found' };
        }
        const request = rows[0];
        if (request.requesterUsername === reviewer) {
            await connection.rollback();
            return { error: 'self-review' };
        }
        const [accounts] = await connection.execute(
            `SELECT status FROM phub_accounts WHERE username = ? FOR UPDATE`,
            [request.requesterUsername]
        );
        if (!accounts.length || accounts[0].status !== 'active') {
            await connection.rollback();
            return { error: 'inactive-account' };
        }
        const decidedAt = new Date();
        await connection.execute(
            `UPDATE phub_promotion_requests
             SET status = ?, reviewed_by = ?, decision = ?, decision_date = ?
             WHERE id = ?`,
            [decision, reviewer, decision, mysqlDate(decidedAt), id]
        );
        if (decision === 'Approved') {
            await connection.execute(
                `UPDATE phub_accounts SET role = 'Head Nurse' WHERE username = ?`,
                [request.requesterUsername]
            );
        }
        await connection.commit();
        return {
            request: {
                ...request,
                status: decision,
                reviewedBy: reviewer,
                decision,
                decisionDate: decidedAt.toISOString()
            },
            promotedUsername: decision === 'Approved' ? request.requesterUsername : null
        };
    } catch (err) {
        await connection.rollback();
        throw err;
    } finally {
        connection.release();
    }
}

async function listAccounts() {
    return loadAccounts();
}

async function loadCleaningSchedules() {
    const [rows] = await pool.query(`
        SELECT s.id, s.Bed_id AS bedId, b.Room_id AS room,
               ROW_NUMBER() OVER (PARTITION BY b.Room_id ORDER BY b.Bed_id) AS bedNumber,
               DATE_FORMAT(s.starts_at, '%Y-%m-%dT%H:%i:%s.%fZ') AS start,
               DATE_FORMAT(s.ends_at, '%Y-%m-%dT%H:%i:%s.%fZ') AS end,
               s.status
        FROM phub_cleaning_schedules s
        JOIN beds b ON b.Bed_id = s.Bed_id
        ORDER BY s.starts_at, s.id
    `);
    return rows.map(item => ({ ...item, id: Number(item.id), bedNumber: Number(item.bedNumber) }));
}

async function syncStartedCleaningBeds() {
    await pool.query(`
        UPDATE beds b
        JOIN phub_cleaning_schedules s ON s.Bed_id = b.Bed_id
        LEFT JOIN patient_assignment pa
          ON pa.Bed_id = b.Bed_id AND pa.discharge IS NULL
        SET b.Status = 'Cleaning'
        WHERE s.starts_at <= UTC_TIMESTAMP(3)
          AND b.Status = 'Available'
          AND pa.PatientAssignment_id IS NULL
    `);
}

async function importCleaningSchedules(schedules) {
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        const [counts] = await connection.query(
            'SELECT COUNT(*) AS count FROM phub_cleaning_schedules'
        );
        if (Number(counts[0].count) !== 0) {
            await connection.rollback();
            return false;
        }
        for (const schedule of schedules) {
            const startsAt = mysqlDate(schedule.start);
            const endsAt = mysqlDate(schedule.end);
            const [beds] = await connection.execute(
                'SELECT Status FROM beds WHERE Bed_id = ? FOR UPDATE',
                [schedule.bedId]
            );
            if (!beds.length || !['Available', 'Cleaning'].includes(beds[0].Status)) {
                throw new Error(`Cannot import cleaning schedule for bed ${schedule.bedId}.`);
            }
            const [patients] = await connection.execute(
                'SELECT 1 FROM patient_assignment WHERE Bed_id = ? AND discharge IS NULL LIMIT 1',
                [schedule.bedId]
            );
            if (patients.length) {
                throw new Error(`Cannot import cleaning schedule for occupied bed ${schedule.bedId}.`);
            }
            await connection.execute(
                `INSERT INTO phub_cleaning_schedules (Bed_id, starts_at, ends_at, status)
                 VALUES (?, ?, ?, ?)`,
                [schedule.bedId, startsAt, endsAt, schedule.status]
            );
            if (new Date(schedule.start) <= new Date()) {
                await connection.execute(
                    "UPDATE beds SET Status = 'Cleaning' WHERE Bed_id = ?",
                    [schedule.bedId]
                );
            }
        }
        await connection.commit();
        return true;
    } catch (err) {
        await connection.rollback();
        throw err;
    } finally {
        connection.release();
    }
}

async function createCleaningSchedule({ bedId, start, end, status = 'Cleaning Scheduled' }) {
    const startsAt = mysqlDate(start);
    const endsAt = mysqlDate(end);
    if (new Date(start).getTime() < Date.now() - 60 * 1000 ||
        new Date(end).getTime() < new Date(start).getTime() + 48 * 60 * 60 * 1000) {
        throw Object.assign(new Error('Cleaning must start in the future and last at least 48 hours.'), { status: 400 });
    }
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        const [beds] = await connection.execute(
            'SELECT Status FROM beds WHERE Bed_id = ? FOR UPDATE',
            [bedId]
        );
        if (!beds.length) {
            await connection.rollback();
            return { error: 'bed-not-found' };
        }
        if (!['Available', 'Cleaning'].includes(beds[0].Status)) {
            await connection.rollback();
            return { error: 'bed-unavailable' };
        }
        const [patients] = await connection.execute(
            'SELECT 1 FROM patient_assignment WHERE Bed_id = ? AND discharge IS NULL LIMIT 1',
            [bedId]
        );
        if (patients.length) {
            await connection.rollback();
            return { error: 'bed-occupied' };
        }
        await connection.execute(
            `INSERT INTO phub_cleaning_schedules (Bed_id, starts_at, ends_at, status)
             VALUES (?, ?, ?, ?)`,
            [bedId, startsAt, endsAt, status]
        );
        if (new Date(start) <= new Date()) {
            await connection.execute("UPDATE beds SET Status = 'Cleaning' WHERE Bed_id = ?", [bedId]);
        }
        await connection.commit();
        return { created: true };
    } catch (err) {
        await connection.rollback();
        throw err;
    } finally {
        connection.release();
    }
}

async function updateCleaningSchedule(id, start, end, status = 'Cleaning Scheduled') {
    const startsAt = mysqlDate(start);
    const endsAt = mysqlDate(end);
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        const [rows] = await connection.execute(
            `SELECT s.Bed_id AS bedId,
                    DATE_FORMAT(s.starts_at, '%Y-%m-%dT%H:%i:%s.%fZ') AS start,
                    DATE_FORMAT(s.ends_at, '%Y-%m-%dT%H:%i:%s.%fZ') AS end
             FROM phub_cleaning_schedules s
             WHERE s.id = ?
             FOR UPDATE`,
            [id]
        );
        if (!rows.length) {
            await connection.rollback();
            return { error: 'not-found' };
        }
        const schedule = rows[0];
        const wasOverdue = new Date(schedule.end) < new Date();
        if (new Date(end).getTime() < new Date(start).getTime() + 48 * 60 * 60 * 1000 ||
            (wasOverdue && new Date(start).getTime() < Date.now()) ||
            (!wasOverdue && (new Date(start).getTime() !== new Date(schedule.start).getTime() ||
                new Date(end).getTime() <= new Date(schedule.end).getTime()))) {
            await connection.rollback();
            return { error: 'invalid-change' };
        }
        const [patients] = await connection.execute(
            'SELECT 1 FROM patient_assignment WHERE Bed_id = ? AND discharge IS NULL LIMIT 1',
            [schedule.bedId]
        );
        if (patients.length) {
            await connection.rollback();
            return { error: 'bed-occupied' };
        }
        await connection.execute(
            `UPDATE phub_cleaning_schedules SET starts_at = ?, ends_at = ?, status = ?
             WHERE id = ?`,
            [startsAt, endsAt, status, id]
        );
        await connection.execute(
            'UPDATE beds SET Status = ? WHERE Bed_id = ?',
            [new Date(start) <= new Date() ? 'Cleaning' : 'Available', schedule.bedId]
        );
        await connection.commit();
        return { updated: true };
    } catch (err) {
        await connection.rollback();
        throw err;
    } finally {
        connection.release();
    }
}

async function completeCleaningSchedule(id) {
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        const [rows] = await connection.execute(
            'SELECT Bed_id AS bedId FROM phub_cleaning_schedules WHERE id = ? FOR UPDATE',
            [id]
        );
        if (!rows.length) {
            await connection.rollback();
            return { error: 'not-found' };
        }
        const [patients] = await connection.execute(
            'SELECT 1 FROM patient_assignment WHERE Bed_id = ? AND discharge IS NULL LIMIT 1',
            [rows[0].bedId]
        );
        if (patients.length) {
            await connection.rollback();
            return { error: 'bed-occupied' };
        }
        await connection.execute('DELETE FROM phub_cleaning_schedules WHERE id = ?', [id]);
        await connection.execute(
            "UPDATE beds SET Status = 'Available' WHERE Bed_id = ?",
            [rows[0].bedId]
        );
        await connection.commit();
        return { completed: true };
    } catch (err) {
        await connection.rollback();
        throw err;
    } finally {
        connection.release();
    }
}

module.exports = {
    migrateLegacyFiles,
    loadAccounts,
    insertAccount,
    deleteAccount,
    insertAuditEvent,
    insertInvitation,
    redeemInvitation,
    listValidInvitations,
    validateInvitation,
    createPromotionRequest,
    listPendingPromotionRequests,
    latestPromotionRequest,
    decidePromotionRequest,
    listAccounts,
    loadCleaningSchedules,
    syncStartedCleaningBeds,
    importCleaningSchedules,
    createCleaningSchedule,
    updateCleaningSchedule,
    completeCleaningSchedule
};
