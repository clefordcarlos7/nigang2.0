-- Adds the rooms and beds represented by public/floor-plan.html.
-- INSERT IGNORE keeps existing clinical records and assignments intact.
INSERT IGNORE INTO rooms (Room_id, Room_type) VALUES
    ('101', 'Ward'), ('102', 'Private'), ('103', 'Ward'), ('104', 'Ward'), ('105', 'Private'),
    ('201', 'Private'), ('202', 'Private'), ('203', 'Private'), ('204', 'Semi-Private'), ('205', 'Semi-Private'), ('206', 'Ward'),
    ('301', 'Private'), ('302', 'Private'), ('303', 'Private'), ('304', 'Semi-Private'), ('305', 'Semi-Private'), ('306', 'Ward');

INSERT IGNORE INTO beds (Bed_id, Status, Room_id) VALUES
    ('FP-101-A', 'Available', '101'), ('FP-101-B', 'Available', '101'),
    ('FP-102-A', 'Available', '102'),
    ('FP-103-A', 'Available', '103'), ('FP-103-B', 'Available', '103'), ('FP-103-C', 'Available', '103'),
    ('FP-104-A', 'Available', '104'), ('FP-104-B', 'Available', '104'), ('FP-104-C', 'Available', '104'), ('FP-104-D', 'Available', '104'),
    ('FP-105-A', 'Available', '105'),
    ('FP-201-A', 'Available', '201'), ('FP-202-A', 'Available', '202'), ('FP-203-A', 'Available', '203'),
    ('FP-204-A', 'Available', '204'), ('FP-204-B', 'Available', '204'),
    ('FP-205-A', 'Available', '205'), ('FP-205-B', 'Available', '205'),
    ('FP-206-A', 'Available', '206'), ('FP-206-B', 'Available', '206'), ('FP-206-C', 'Available', '206'), ('FP-206-D', 'Available', '206'),
    ('FP-301-A', 'Available', '301'), ('FP-302-A', 'Available', '302'), ('FP-303-A', 'Available', '303'),
    ('FP-304-A', 'Available', '304'), ('FP-304-B', 'Available', '304'),
    ('FP-305-A', 'Available', '305'), ('FP-305-B', 'Available', '305'),
    ('FP-306-A', 'Available', '306'), ('FP-306-B', 'Available', '306'), ('FP-306-C', 'Available', '306'), ('FP-306-D', 'Available', '306');
