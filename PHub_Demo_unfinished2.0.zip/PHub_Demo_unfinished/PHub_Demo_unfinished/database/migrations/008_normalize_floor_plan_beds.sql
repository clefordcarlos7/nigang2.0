-- Align floor-plan beds with Manage Rooms:
-- Ward = 4 beds, Private = 1 bed, Semi-Private = 2 beds.
-- Bed IDs use <room>-<letter> (for example, 101-A).
START TRANSACTION;

DELETE s
FROM phub_cleaning_schedules s
JOIN beds b ON b.Bed_id = s.Bed_id
LEFT JOIN beds canonical
    ON canonical.Room_id = b.Room_id
   AND canonical.Bed_id = CONCAT(b.Room_id, '-A')
LEFT JOIN patient_assignment pa ON pa.Bed_id = b.Bed_id
WHERE b.Bed_id LIKE 'FP-%'
  AND canonical.Bed_id IS NOT NULL
  AND pa.Bed_id IS NULL;

DELETE b
FROM beds b
LEFT JOIN beds canonical
    ON canonical.Room_id = b.Room_id
   AND canonical.Bed_id = CONCAT(b.Room_id, '-A')
LEFT JOIN patient_assignment pa ON pa.Bed_id = b.Bed_id
WHERE b.Bed_id LIKE 'FP-%'
  AND canonical.Bed_id IS NOT NULL
  AND pa.Bed_id IS NULL;

UPDATE beds
SET Bed_id = CONCAT(Room_id, '-', RIGHT(Bed_id, 1))
WHERE Bed_id LIKE 'FP-%';

INSERT IGNORE INTO beds (Bed_id, Status, Room_id) VALUES
    ('101-C', 'Available', '101'),
    ('101-D', 'Available', '101');

DELETE FROM beds
WHERE Bed_id LIKE '%-E'
  AND EXISTS (
      SELECT 1 FROM rooms r
      WHERE r.Room_id = beds.Room_id
        AND r.Room_type IN ('Private', 'Semi-Private')
  );

DELETE FROM beds
WHERE Bed_id LIKE '%-C'
  AND EXISTS (
      SELECT 1 FROM rooms r
      WHERE r.Room_id = beds.Room_id
        AND r.Room_type = 'Private'
  );

DELETE FROM beds
WHERE Bed_id LIKE '%-D'
  AND EXISTS (
      SELECT 1 FROM rooms r
      WHERE r.Room_id = beds.Room_id
        AND r.Room_type IN ('Private', 'Semi-Private')
  );

COMMIT;
