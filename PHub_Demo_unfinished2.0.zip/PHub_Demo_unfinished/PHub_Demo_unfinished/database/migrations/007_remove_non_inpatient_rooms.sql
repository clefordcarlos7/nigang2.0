-- Emergency and consultation areas are static floor-plan areas, not clinical rooms.
-- Remove only room records using those non-inpatient room types and their
-- unassigned dependent records. Patient history is never deleted by this
-- migration.
START TRANSACTION;

CREATE TEMPORARY TABLE phub_non_inpatient_beds (
    Bed_id VARCHAR(20) PRIMARY KEY
);

INSERT INTO phub_non_inpatient_beds (Bed_id)
SELECT b.Bed_id
FROM beds b
JOIN rooms r ON r.Room_id = b.Room_id
WHERE LOWER(r.Room_type) IN ('emergency room', 'consultation', 'consultation room');

DELETE FROM phub_cleaning_schedules
WHERE Bed_id IN (SELECT Bed_id FROM phub_non_inpatient_beds);

DELETE FROM nurse_assignment
WHERE Room_id IN (
    SELECT Room_id
    FROM rooms
    WHERE LOWER(Room_type) IN ('emergency room', 'consultation', 'consultation room')
);

DELETE FROM beds
WHERE Bed_id IN (SELECT Bed_id FROM phub_non_inpatient_beds)
  AND NOT EXISTS (
      SELECT 1
      FROM patient_assignment pa
      WHERE pa.Bed_id = beds.Bed_id
  );

DELETE FROM rooms
WHERE LOWER(Room_type) IN ('emergency room', 'consultation', 'consultation room')
  AND NOT EXISTS (
      SELECT 1
      FROM beds b
      WHERE b.Room_id = rooms.Room_id
  );

DROP TEMPORARY TABLE phub_non_inpatient_beds;
COMMIT;
